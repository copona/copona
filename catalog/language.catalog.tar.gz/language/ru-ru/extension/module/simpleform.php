<?php
$_['heading_title'] = 'Nepraleiskite progos ir papuoškite savo „Porsche“ originaliais ratais:';
$_['text_contact'] = 'Sazinaties ar mums';
$_['text_sitemap'] = 'Vietnes karte';
$_['text_registration_name'] = 'Vardas';
$_['text_registration_surname'] = 'Pavardė';
$_['text_registration_phone'] = 'Telefonas';
$_['text_registration_email'] = 'Elektroninis paštas';
$_['text_registration_regnumber'] = 'Jūsų vairuojamas automobilis';
$_['text_registration_warning'] = 'Būtini laukai. Gavę Jūsų užklausą su Jumis sisisieksime asmeniškai.';
$_['text_registration_title'] = 'Registracija pasiūlymui gauti';
?>