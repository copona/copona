<?php
// Heading
$_['heading_title'] = 'Kļūda!';

// Text
$_['text_error']    = 'Uzmanību: Jūsu pieprasītā vietne netika atrasta!';
?>