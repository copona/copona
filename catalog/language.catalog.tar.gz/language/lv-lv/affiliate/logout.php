<?php
// Heading 
$_['heading_title'] = 'Jūs izgājāt no profila';

// Text
$_['text_message']  = '<p>Jūs veiksmīgi esat izgājuši no sava profila. Tagad Jūs var droši atstāt veikalu.</p><p>Jūsu pirkumu grozs ir saglabāts un tiks atjaunots pie nākamās tikšanās reizes.</p>';
$_['text_account']  = 'Mans profils';
$_['text_logout']   = 'Veikals';

$_['button_continue']    = 'Aizvērt logu';
?>