<?php
// Heading 
$_['heading_title']  = 'Paroles maiņa';

// Text
$_['text_account']   = 'Mans profils';
$_['text_password']  = 'Jūsu jaunā parole';
$_['text_success']   = 'Jūsu parole ir veiksmīgi labota!';

// Entry
$_['entry_password'] = 'Parole:';
$_['entry_confirm']  = 'Atkārtojiet paroli:';

// Error
$_['error_password'] = 'Uzmanību: Jūsu parolei ir jābūt no 4 līdz 20 rakstzīmēm!';
$_['error_confirm']  = 'Uzmanību: Jūsu ievadītā parole nesakrīt!';

$_['button_continue']    = 'Saglabāt';
?>