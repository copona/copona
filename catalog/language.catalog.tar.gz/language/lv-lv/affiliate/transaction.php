<?php
// Heading 
$_['heading_title']      = 'Transakcijas';

// Column
$_['column_date_added']  = 'Pievienots';
$_['column_description'] = 'Apraksts';
$_['column_amount']      = 'Summa';

// Text
$_['text_account']       = 'Mans profils';
$_['text_transaction']   = 'Transakcijas';
$_['text_balance']       = 'Jūsu bilance ir:';
$_['text_empty']         = 'Dotajā mirklī Jums vel nav nevienas transakcijas!';

$_['button_continue'   ] = 'Aizvērt logu';
?>