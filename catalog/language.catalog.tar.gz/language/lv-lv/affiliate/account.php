<?php
// Heading 
$_['heading_title']        = 'Partneru profils';

// Text
$_['text_account']         = 'Mans profils';
$_['text_my_account']      = 'Mans partnra profils';
$_['text_my_tracking']     = 'Sekošanas informācija';
$_['text_my_transactions'] = 'Transakcijas';
$_['text_edit']            = 'Labot profilu';
$_['text_password']        = 'Mainīt paroli';
$_['text_payment']         = 'Maksāšanas uzstādījumus';
$_['text_tracking']        = 'Izveidot sekošanas saiti(es)';
$_['text_transaction']     = 'Skatīt transakcijas vēsturi';
?>