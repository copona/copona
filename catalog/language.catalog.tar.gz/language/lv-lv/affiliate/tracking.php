<?php
// Heading 
$_['heading_title']    = 'Izveidot sekošanas saiti(es)';

// Text
$_['text_account']     = 'Mans profils';
$_['text_description'] = 'Lai būt drošam, ka jūs saņemat samaksu par reklamēto preci, saitei ir nepieciešams, sekošanas kods, kurš jāpievieno pie katras reklamētās preces, kas savienojās ar mūsu veikalu. Šo rīku Jūs varat izmantot, lai izveidot saites uz %s portālu.';
$_['text_code']        = '<b>Sekošanas kods:</b>';
$_['text_generator']   = '<b>Sekošanas saites automātiskais ģenerators</b><br />Ievadiet preces nosaukumu, kuru vēlaties reklamēt:';
$_['text_link']        = '<b>Sekošanas saite:</b>';
?>