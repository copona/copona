<?php
$_['text_title'] = '';
$_['text_description'] = 'Piegāde';
?>