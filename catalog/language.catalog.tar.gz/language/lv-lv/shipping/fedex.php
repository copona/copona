<?php
// Text
$_['text_title']       = 'Fedex';
$_['text_description'] = 'Fedex';
?>