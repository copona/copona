<?php
// Text
$_['text_title']       = 'Preces saņemšana veikalā (bezmaksas)';
$_['text_description'] = 'Preces saņemšana veikalā (bezmaksas)';
?>