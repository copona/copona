<?php
// Text
$_['text_title']                = 'Royal Mail';
$_['text_weight']               = 'Svars:';
$_['text_insurance']            = 'Insured upto:';
$_['text_eta']                  = 'Estimated Time:';
$_['text_1st_class_standard']   = 'First Class Standard Post';
$_['text_1st_class_recorded']   = 'First Class Recorded Post';
$_['text_2nd_class_standard']   = 'Second Class Standard Post';
$_['text_2nd_class_recorded']   = 'Second Class Recorded Post';
$_['text_standard_parcels']     = 'Standard Parcels';
$_['text_airmail']              = 'Airmail';
$_['text_international_signed'] = 'International Signed';
$_['text_airsure']              = 'Airsure';
$_['text_surface']              = 'Surface';
?>