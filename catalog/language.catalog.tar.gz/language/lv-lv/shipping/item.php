<?php
// Text
$_['text_title']       = 'Piegāde par vienību';
$_['text_description'] = 'Piegāde par vienībus likmi';
?>