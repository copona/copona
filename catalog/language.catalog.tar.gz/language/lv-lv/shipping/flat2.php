<?php
$_['text_description'] = 'Vēlos saņemt preci ar OMNIVA pakomātu';
?>