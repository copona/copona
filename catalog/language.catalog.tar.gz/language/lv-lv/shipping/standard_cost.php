<?php
$_['text_title'] = 'Piegāde ar kurjeru';
$_['text_weight'] = 'Pirkuma summa:';
$_['text_costs'] = 'Piegādes izmaksas:';
$_['text_location'] = 'Piegāde Latvijas teritorijā';
?>