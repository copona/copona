<?php
$_['text_description'] = 'BEZMAKSAS (Pirkumiem Latvijā virs 50EUR, Rīgā virs 25EUR, Ogrē virs 15EUR)';
?>