<?php
//-----------------------------------------
// OpenCart Australia Post Shipping Module
// Version: 1.1
// Author: SuperJuice (Sam)
// Email: opencart@pixeldrift.net
// Web: http://www.pixeldrift.net/opencart/
//-----------------------------------------

// Text
$_['text_title']       = 'Australia Post';
$_['text_express']     = 'Australia Post Express';
$_['text_standard']      = 'Australia Post Standard';
?>
