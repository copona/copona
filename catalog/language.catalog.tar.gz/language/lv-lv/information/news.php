<?php
// Heading
$_['heading_title'] = 'Jaunumi';
 
// Text
$_['text_title'] = '';
$_['text_read_more'] = 'Lasīt vairāk';
$_['text_description'] = '';
$_['text_date'] = 'Pievienots';
$_['text_view'] = 'Lasīt';
$_['text_error'] = 'Diemžēl šī lapa neeksistē.';
?>