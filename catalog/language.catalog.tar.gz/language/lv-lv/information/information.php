<?php
$_['text_error'] = 'Uzmanību: Lapa nav atrasta vai vairāk neeksistē!';
?>