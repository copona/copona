<?php
// Text
$_['text_error'] = 'Uzmanibu: Kategorija nav atrasta!';
?>