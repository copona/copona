<?php
$_['text_product'] = 'Prece:';
$_['column_product'] = 'Prece';
$_['text_status_pending'] = 'Procesā';
?>