<?php
$_['heading_title'] = 'Pasūtījumu vēsture';
$_['text_account'] = 'Mans profils';
$_['text_success'] = 'Iepriekšējā pasūtījuma Nr. #%s preces pievienotas Jūsu grozam!';
$_['text_order'] = 'Rēķins';
$_['text_order_detail'] = 'Rēķina informācija';
$_['text_invoice_no'] = 'Rēķina Nr.:';
$_['text_order_id'] = 'Rēķina Nr.:';
$_['text_status'] = 'Stāvoklis:';
$_['text_date_added'] = 'Pasūtījuma datums:';
$_['text_customer'] = 'Pircējs:';
$_['text_shipping_address'] = 'Piegādes adrese';
$_['text_shipping_method'] = 'Piegādes veids:';
$_['text_payment_address'] = 'Maksātājs';
$_['text_payment_method'] = 'Maksāšanas veids:';
$_['text_products'] = 'Preces:';
$_['text_total'] = 'Kopā:';
$_['text_comment'] = 'Pasūtījuma komentāri';
$_['text_history'] = 'Pasūtījuma vēsture';
$_['text_empty'] = 'Dotajā mirklī Jums vel nav neviena pasūtījuma!';
$_['text_error'] = 'Uzmanību: Jūsu pieprasītais pasūtījums nav atrasts!';
$_['column_name'] = 'Preces nosaukums';
$_['column_model'] = 'Modelis';
$_['column_quantity'] = 'Daudzums';
$_['column_price'] = 'Cena';
$_['column_total'] = 'Summa';
$_['column_date_added'] = 'Pievienots';
$_['column_status'] = 'Stāvoklis';
$_['column_comment'] = 'Komentāri';
$_['button_continue'] = 'Aizvērt logu';
$_['column_action'] = 'Darbības';
$_['column_order_id'] = 'Pasūtījuma Nr.';
$_['column_product'] = 'Preču skaits';
$_['column_customer'] = 'Pircējs';

//GS
$_['text_order_payer'] 			= "Maksātājs";
$_['text_order_header'] 		= "Rēķina informācija";

$_['customer_group_id'] 		= '<b>Maksātājs</b>';
$_['customer_group_id_1'] 		= 'Fiziska persona';
$_['customer_group_id_2'] 		= 'Juridiska persona';
$_['company_name'] 				= '<b>Uzņēmuma nosaukums</b>';
$_['reg_num'] 					= '<b>Reģistrācijas numurs</b>';
$_['vat_num'] 					= '<b>PVN numurs</b>';
$_['bank_name'] 				= '<b>Bankas nosaukums</b>';
$_['bank_code'] 				= '<b>Bankas kods</b>';
$_['bank_account'] 				= '<b>Konta numurs</b>'; 
$_['address_2'] 				= '<b>Juridiskā adrese</b>';

$_['text_first_last_name']		= 'Vārds Uzvārds';
$_['text_email']			 	= 'E-pasts';
$_['text_phone']				= 'Tālrunis';

$_['text_owner_rekviziti'] = '<b></b> SIA "Datorveikals"<br />
					<b>Reģ. Nr.:</b> xxxx<br />
					<b>PVN Nr.:</b> LVxxxx<br />
					<b>Juridiskā adrese:</b> Lielā iela 38-1, Rīga , LV – 1000<br />
					<b>Bankas nosaukums:</b> AS ”Swedbank”<br />
					<b>Bankas kods:</b> HABALV22<br />
					<b>Konts:</b> LV86HABAxxxx<br />';
$_['text_new_email'] 			= 'E-pasts:';
$_['text_new_telephone'] 		= 'Tālrunis:';

$_['text_other_info'] = '<b>Samaksas veids:</b> Priekšapmaksa<br />
					     <b>Valūta:</b> EUR<br />';
					     
$_['text_new_order_detail'] = 'Saņēmējs';
?>