<?php
// Heading 
$_['heading_title']         = 'Pasūtījuma rēķins';

// Text
$_['text_account']          = 'Konts';
$_['text_history']          = 'Pasūtījumu vēsture';
$_['text_invoice']          = 'Rēķins';
$_['text_invoice_id']       = 'Rēķina numurs';
$_['text_order_id']         = 'Pasūtījuma numurs';
$_['text_email']            = 'E-pasts';
$_['text_telephone']        = 'Telefona numurs';
$_['text_fax']              = 'Fakss';
$_['text_shipping_address'] = 'Piegādes adrese';
$_['text_shipping_method']  = 'Piegādes veids';
$_['text_payment_address']  = 'Maksātāja adrese';
$_['text_payment_method']   = 'Maksājuma veids';
$_['text_order_history']    = 'Pasūtījumu vēsture';
$_['text_product']          = 'Produkts';
$_['text_model']            = 'Modelis';
$_['text_quantity']         = 'Daudzums';
$_['text_price']            = 'Vienības cena';
$_['text_total']            = 'Summa';
$_['text_comment']          = 'Pasūtījuma komentāri / piebildes';
$_['text_error']            = 'Pieprasītais rēķins netika atrasts!';

// Column
$_['column_date_added']     = 'Pievienošanas datums';
$_['column_status']         = 'Statuss';
$_['column_comment']        = 'Komentāri';
?>
