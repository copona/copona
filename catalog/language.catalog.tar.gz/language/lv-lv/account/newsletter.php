<?php
// Heading 
$_['heading_title']    = 'Izsūtnes abonēšana';

// Text
$_['text_account']     = 'Mans profils';
$_['text_newsletter']  = 'Izsūtnes abonēšana';
$_['text_success']     = 'Jūsu izsūtnes uzstādījumi ir veiksmīgi laboti!';

// Buttons
$_['button_continue']  = 'Saglabāt';

// Entry
$_['entry_newsletter'] = 'Vai vēlaties abonēt?:';
?>
