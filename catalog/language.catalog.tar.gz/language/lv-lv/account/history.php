<?php
// Heading 
$_['heading_title']   = 'Manu pasūtījumu vēsture';

// Text
$_['text_account']    = 'Konts';
$_['text_history']    = 'Pasūtījumu vēsture';
$_['text_order']      = 'Pasūtījuma nummurs:';
$_['text_status']     = 'Statuss:';
$_['text_date_added'] = 'Pievienošanas datums:';
$_['text_customer']   = 'Klients / pircējs:';
$_['text_products']   = 'Produkti:';
$_['text_total']      = 'Summa:';
$_['text_error']      = 'Jūs neesat iepriekš veicis pasūtījumus!';
?>
