<?php
$_['text_handling'] = 'Apstrādes maksa:';
?>