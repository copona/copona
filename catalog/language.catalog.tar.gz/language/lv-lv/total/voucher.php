<?php
// Heading 
$_['heading_title'] = 'Piemērot dāvanu karti';

// Text
$_['text_voucher']  = 'Dāvanu karte (%s):';
$_['text_success']  = 'Jūsu dāvanu karte ir veiksmīgi piemērota!';

// Entry
$_['entry_voucher'] = 'Ievadiet dāvanu kartes kodu:';

// Error
$_['error_voucher'] = 'Uzmanību: Dāvanu kartes kods ievadīts nepareizi, bilance ir izlietota vai arī tās derīguma termiņš ir beidzies!';
?>