<?php
// Heading 
$_['heading_title'] = 'Piemērot atlaides kuponu';

// Text
$_['text_coupon']   = 'Atlaides kods (%s):';
$_['text_success']  = 'Jūsu atlaides kods ir sekmīgi piemērots.';

// Entry
$_['entry_coupon']  = 'Ievadiet atlaides kodu:';

// Error
$_['error_coupon']  = 'Uzmanību: Atlaides kods ievadīts nepareizi, nav derīgs, beidzies derīguma termiņš vai lietošanas limits ir pārsniegts!';
?>