<?php
$_['text_sub_total'] = 'Summa';
$_['text_tax_name'] = 'PVN';