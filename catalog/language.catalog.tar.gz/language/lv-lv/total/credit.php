<?php
$_['text_credit']   = 'Veikala kredīts:';
$_['text_order_id'] = 'Pasūtījuma Nr.: #%s';
?>