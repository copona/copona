<?php
//For all
$_['lb_yes']   				 					 = "Jā";
$_['lb_no']   				 		 			 = "Nē";
$_['btn_new']									 = "Jauns";
$_['btn_save']									 = "Saglabāt";
$_['btn_edit']									 = "Labot";
$_['btn_delete']									 = "Dzēst";
$_['btn_cancel']									 = "Atcelt";
$_['btn_clear']									 = "Notīrīt";
$_['btn_search']									 = "Meklēt";
$_['btn_chouse']									 = "Izvēlies";
$_['btn_close']									 = "Aizvērt";
$_['btn_select']									 = "Atlasīt";
$_['with_vat']									 = "Summa %01.2f %s ar PVN";
$_['with_vat_short']								 = "%01.2f %s ar PVN";



//------- JS datatable
$_['js_dt_search']   				   		 	 = "Meklēt:";
$_['js_dt_not_found']   				 			 = "Neviens ieraksts netika atrasts";
$_['js_dt_in_proccess']   				 		 = "Procesā...";
$_['js_dt_loading']   				 			 = "Ielāde...";
$_['js_dt_show']   						 		 = "Rādīt";
$_['js_dt_enteries']   					 		 = "ierakstus";
$_['js_dt_from']   						 		 = "(atlasīts no";
$_['js_dt_to']   						 		 = "ierakstiem)";
$_['js_dt_msg1']   						 		 = "Redzams 0 līdz 0 no 0 ierakstiem";
$_['js_dt_show1']   						 		 = "Redzams";
$_['js_dt_show2']   						 		 = "līdz";
$_['js_dt_show3']   						 		 = "no";
$_['js_dt_show4']   						 		 = "ierakstiem";
$_['js_dt_no_data']   				 			 = "Tabulā nav datu";
$_['js_dt_perv']   						 		 = "Iepriekšējie";
$_['js_dt_next']   						 		 = "Nākamie";
$_['js_dt_last']   						 		 = "Pēdējais";
$_['js_dt_first']   						 		 = "Pirmais";

//------- Login
$_['login_login_title']   				 		 = "Autorizēšanās";
$_['login_forgot_password']						 = "Aizmirsi paroli";
$_['login_contact_us']							 = "Sazinies ar mums";
$_['login_log_in']					 			 = "Autorizēšanās";
$_['login_lbl_login']							 = "Lietotāja vārds";
$_['login_lbl_password']						     = "Parole";
$_['login_btn_login']					 		 = "Ienākt";
$_['login_modal_forgot_password']				 = "Aizmirsi paroli";
$_['login_modal_forgot_password_title']			 = "Ievadi savu Lietotāja vārdu, lai atjaunotu paroli";
$_['login_modal_lbl_username']					 = "Lietotāja vārds";
$_['login_modal_btn_send']						 = "Sūtīt";
$_['login_modal_btn_close']						 = "Aizvērt";
$_['login_modal_contact_us']						 = "Sazinies ar mums";
$_['login_modal_name']							 = "Vārds";
$_['login_modal_email']							 = "E-pasts";
$_['login_modal_message']					 	 = "Jūsu ziņa";
$_['login_err_username']							 = "Nepareizs lietotāja vārds vai parole!";
$_['login_err_no_username']						 = "Lietotāja vārds nav ievadīts!";
$_['login_msg_subject']							 = "Paroles atjaunošana";
$_['login_mgs_forgot_pass_1']					 = "Jūs esat pieprasījuši paroles maiņu.<br> Jūsu jaunā parole ir: <b>";
$_['login_mgs_forgot_pass_2']					 = "</b> <br> Ieejot sistēmā lūgums nomainīt paroli uz sevis izvēlētu.";
$_['login_mgs_forgot_pass_3']					 = "Parole lietotājam ";
$_['login_mgs_forgot_pass_4']					 = "atjaunota un nosūtīta uz epastu!";
$_['login_mgs_forgot_pass_5']					 = "netika nosūtīta! \\n Lūdzu sazinieties ar mums personīgi!";
$_['login_mgs_forgot_pass_6']					 = "Lietotāja vārds";
$_['login_mgs_forgot_pass_7']					 = "netika atrasts!";
$_['login_msg_contact_no_name']					 = "Lauks Vārds nav ievadīts! \\n";
$_['login_msg_contact_no_email']					 = "Lauks E-pasts nav ievadīts! \\n";
$_['login_msg_contact_no_msg']					 = "Lauks Ziņa nav ievadīts! \\n";
$_['login_msg_contact_lbl_name']					 = "Vārds:";
$_['login_msg_contact_lbl_email']				 = "E-pasts:";
$_['login_msg_contact_lbl_msg']					 = "Ziņa:";
$_['login_msg_contact_subject']					 = "Ziņa no sazinies ar mums.";
$_['login_mgs_forgot_pass_8']					 = "Ziņa veiksmīgi nosūtīta!";
$_['login_mgs_forgot_pass_9']					 = "Ziņa netika nosūtīta. Mēģiniet vēl!";

//------- Dashboard
$_['dash_new_issue']					 			 = "Jauns pieteikums";
$_['dash_new_client']		 					 = "Jauns klients";
$_['dash_my_profile']		 					 = "Mans profils";
$_['dash_newest_issue_tickets']					 = "Jaunākie servisa pieteikumi";
$_['dash_user_activity']							 = "Lietotāju aktivitāte";
$_['dash_last_changes']					 		 = "Pēdējās izmaiņas";
$_['dash_newest_clients']						 = "Jaunākie klienti";
$_['dash_title']									 = "Sākums";
$_['dash_user']									 = "Lietotājs";
$_['dash_visits']				 				 = "Apmeklējumi";
$_['dash_other']					 				 = "Citi";
$_['dash_col1']					 				 = "Serv. num.";
$_['dash_col2']					 				 = "Pieņ. dat.";
$_['dash_col3']					 			     = "Klients";
$_['dash_col4']					 				 = "Iekārta";
$_['dash_col5']					        		 = "Statuss";
$_['dash_col6']					 			     = "Serviss";
$_['dash_col7']					 			     = "Datums";
$_['dash_col8']					                 = "Aktivitāte";
$_['dash_col9']					                 = "Lietotājs";
$_['dash_col10']					 				 = "Nosaukums";
$_['dash_col11']					 				 = "Tips";
$_['dash_col12']					 				 = "Tālrunis";
$_['dash_col13']					                 = "E-pasts";
$_['dash_col14']					 				 = "Pievienots";

//------- Master page
$_['master_message']					 			 = "Ziņojumi";
$_['master_hello']					 			 = "Sveicināti";
$_['master_exit']					     	     = "Iziet";

//------- Client portal
$_['cportal_tittle']					  			 = "Remonta statusa pārbaude";
$_['cportal_btn_login']				 		     = "Ienākt";
$_['cportal_lbl_issuenr']			 			 = "Servisa Nr.";
$_['cportal_lbl_pass']				 			 = "Parole";
$_['cportal_master_msg1']			 			 = "Servisa pieteikuma nr.:";
$_['cportal_master_msg2']			 			 = "statusa pārbaude";
$_['cportal_master_exit']			 			 = "Iziet";
$_['cportal_err_pass_or_num']		 			 = "Nepareizs servisa numurs vai parole!";
$_['cportal_col1']					 			 = "Statuss";
$_['cportal_col2']					 			 = "Komentārs";
$_['cportal_col3']					 			 = "Datums";
$_['cportal_col4']					 			 = "Darbinieks";
$_['cportal_lb_issue_ticket']		 			 = "Servisa numurs:";
$_['cportal_lb_status']				 			 = "Statuss:";
$_['cportal_lb_repair_start_date']	 			 = "Saņemšanas datums:";
$_['cportal_lb__priority']			 			 = "Prioritāte:";
$_['cportal_lb_client']				 			 = "Klients:";
$_['cportal_lb_division']			 			 = "Serviss:";
$_['cportal_lb_contactperosn']		 			 = "Kontaktpersona:";
$_['cportal_lb_master']				 			 = "Remonta meistars:";
$_['cportal_lb_warranty']			 			 = "Garantija: ";
$_['cportal_lb_potential_cost']		 			 = "Provizoriskās izmaksas:";
$_['cportal_lb_serial']				 			 = "Seriālais numurs:";
$_['cportal_lb_work_cost']			 			 = "Cena par pakalpojumu:";
$_['cportal_lb_brand']				 			 = "Marka:";
$_['cportal_lb_part_cost']			 			 = "Cena par detaļām:";
$_['cportal_lb_model']				 			 = "Modelis:";
$_['cportal_lb_send_email']			 			 = "Sūtīt E-pastus:";
$_['cportal_lb_repair_end_date']		 			 = "Remonta beigu datums:";
$_['cportal_lb_send_sms']			 			 = "Sūtīt SMS:";
$_['cportal_lb_defect']				 			 = "Defekts:";
$_['cportal_lb_notes']				 			 = "Piezīmes:";
$_['cportal_lb_comments']			 			 = "Statusa maiņa un komentāri";
$_['cportal_lb_images']				 			 = "Bildes";

//------- User portal
$_['uportal_btn_edit']					 		 = "Labot";
$_['uportal_btn_change_pass']					 = "Mainīt paroli";
$_['uportal_lb_user_name']					 	 = "Lietotāja vārds";
$_['uportal_lb_name']					 		 = "Vārds:";
$_['uportal_lb_lastname']					  	 = "Uzvārds:";
$_['uportal_lb_email']					 		 = "E-pasts:";
$_['uportal_lb_usermenu']					 	 = "Lietotāja izvēlne:";
$_['uportal_lb_aviable_services']				 = "Pieejamie servisi:";
$_['uportal_lb_register_until']					 = "Reģistrēts kopš:";
$_['uportal_btn_save']					 		 = "Saglabāt";
$_['uportal_btn_cancel']					 		 = "Atcelt";
$_['uportal_new_pass']					 		 = "Jauna parole:";
$_['uportal_new_pass2']					 		 = "Apstiprināt paroli:";
$_['uportal_tittle']								 = "Mans profils";
$_['uportal_page_tittle']					 	 = "Mans profils";
$_['uportal_page_tittle_edit']					 = "Labot mans profils";
$_['uportal_msg1']					 			 = "Mans portāls labošana";
$_['uportal_msg2']								 = "Ieraksts veiksmīgi izlabots!";
$_['uportal_msg3']					 			 = "Mans portāls paroles maiņa";
$_['uportal_msg4']					 			 = "Parole nomainīta veiksmīgi!";
$_['uportal_tittle_change_pass']					 = "Mainīt paroli";

//------- Admin
$_['admin_msg_new']								 ='Jauns ieraksts';
$_['admin_msg_new_1']							 ='Jauns ieraksts pievienots veiksmīgi!';
$_['admin_msg_edit']								 ='Ieraksta labošana';
$_['admin_msg_edit_1']							 ='Ieraksts veiksmīgi izlabots!';
$_['admin_msg_delete']						     ='Dzēst ierakstu';
$_['admin_msg_delete_1']							 ='Ieraksts veiksmīgi dzēsts!';
$_['admin_delete_confirm']					     = "Vai tiešām vēlaties dzēst ierakstu?";

$_['access_tittle']					 			 = "Aktivitāte";
$_['access_page_title']					 		 = "Aktivitāte";
$_['access_col1']					 		     = "N.p.k.";
$_['access_col2']					 			 = "Vārds";
$_['access_col3']								 = "Uzvārds";
$_['access_col4']								 = "Lapa";
$_['access_col5']								 = "Datums";

$_['admin_tittle']					 			 = "Administrēšana";
$_['admin_text1']					 			 = "Admin sadaļa";
$_['admin_text2']					 			 = "Šeit notiek darbs ar portāla lietotājiem, grupām, tiesībām.";

$_['brand_add_new']					 			 = "Jauns";
$_['brand_col1']									 = "N.p.k.";
$_['brand_col2']					 				 = "Ražotāja nosaukums";
$_['brand_col3']					 				 = "Logo";
$_['brand_col4']					         		 = "Piev. dat.";
$_['brand_edit']					 				 = "Labot";
$_['brand_delete']					 			 = "Dzēst";
$_['brand_delete_confirm']					     = "Vai tiešām vēlaties dzēst ierakstu?";
$_['brand_brand_name']					 		 = "Ražotāja nosaukums";
$_['brand_logo']					 				 = "Logo";
$_['brand_title']					 			 = "Iekārtu ražotāji";
$_['brand_title_new']					 		 = "Pievienot iekārtu ražotāju";
$_['brand_itle_edit']					 		 = "Labot iekārtu ražotāju";

$_['div_name']					 				 = "Servisa nosaukums";
$_['div_servise_add']					 		 = "Piesaistīts servisam";
$_['div_address']					 			 = "Adrese";
$_['div_properties']					   			 = "Rekvizīti";
$_['div_tel']					 			     = "Tālrunis";
$_['div_email']					 				 = "E-pasta adrese";
$_['div_work_time']					 			 = "Darba laiks";
$_['div_notes']					 				 = "Piezīmes";
$_['div_service_users']					  		 = "Servisa lietotāji";
$_['div_work']					 				 = "Strādā";
$_['div_col1']					 				 = "N.p.k.";
$_['div_page_title']								 = "Servisi";
$_['div_add_title']								 = "Pievienot servisu";
$_['div_edit_title']					 			 = "Labot servisu";
$_['div_err_msg']					 			 = "Lauka '%s' vērtība jau tiek izmantota!";

$_['men_ite_name']					 		     = "Izvēlnes nosaukums";
$_['men_ite_url']					 			 = "Saite";
$_['men_ite_add_to_menu']						 = "Piesaistīts izvēlnei";
$_['men_ite_pos']					 			 = "Pozīcija";
$_['men_ite_active']					 			 = "Aktīvs";
$_['men_ite_col1']					 			 = "N.p.k.";
$_['men_ite_add_date']					 		 = "Reģ. datums";
$_['men_ite_page_title']					 		 = "Izvēlnes pozīcijas";
$_['men_ite_add_title']					 		 = "Pievienot izvēlnes pozīciju";
$_['men_ite_edit_title']					 	     = "Labot izvēlnes pozīciju";

$_['men_typ_name']					 			 = "Izvēlnes nosaukums";
$_['men_typ_active']					 			 = "Aktīvs";
$_['men_typ_pos']					 			 = "Izvēlnes pozīcijas";
$_['men_typ_desc']					 			 = "S - skatīt, P - pievienot, L - labot, D - dzēst";
$_['men_typ_w']					 				 = "S";
$_['men_typ_a']					 				 = "P";
$_['men_typ_e']					 				 = "L";
$_['men_typ_d']					 			     = "D";
$_['men_typ_col1']					 			 = "N.p.k.";
$_['men_typ_add_date']					 		 = "Reģ. datums";
$_['men_typ_title']					 			 = "Izvēlnes";
$_['men_typ_title_add']					 		 = "Pievienot izvēlni";
$_['men_typ_title_edit']							 = "Labot izvēlni";
$_['men_typ_err_msg']							 = "Lauka '%s' vērtība jau tiek izmantota!";

$_['perm_key']								     = "Tiesību atslēga";
$_['perm_name']					 				 = "Tiesību nosaukums";
$_['perm_col1']					 				 = "N.p.k.";
$_['perm_title']					 				 = "Tiesības";
$_['perm_title_add']								 = "Pievienot tiesības";
$_['perm_title_edit']					 		 = "Labot tiesības";
$_['perm_err_msg']					 			 = "Lauka '%s' vērtība jau tiek izmantota!";

$_['rol_name']					 			     = "Lomas nosaukums";
$_['rol_perms']					 			     = "Lomas tiesības";
$_['rol_enable']					 				 = "Atļauts";
$_['rol_disable']					 			 = "Aizliegts";
$_['rol_col1']					 				 = "N.p.k.";
$_['rol_title']					 				 = "Lomas";
$_['rol_title_add']					 			 = "Pievienot lomu";
$_['rol_title_edit']								 = "Labot lomu";
$_['rol_err_msg']					 			 = "Lauka '%s' vērtība jau tiek izmantota!";

$_['user_name']									 = "Vārds";
$_['user_lastname']								 = "Uzvārds";
$_['user_email']					 				 = "Epasts";
$_['user_username']								 = "Lietotāja vārds";
$_['user_pass']									 = "Parole";
$_['user_menu']					 				 = "Lietotāja izvēlne";
$_['user_active']								 = "Aktīvs";
$_['user_userkind']								 = "Lietotāja veids";
$_['user_role']									 = "Lietotāja lomas";
$_['user_allow']									 = "Atļauts";
$_['user_dissalow']								 = "Aizliegts";
$_['user_col1']					 				 = "N.p.k.";
$_['user_add_date']								 = "Reģ. datums";
$_['user_www_suer']								 = "www lietotājs";
$_['user_soap_user']								 = "soap lietotājs";
$_['user_title']					 				 = "Lietotātji";
$_['user_title_add']					 			 = "Pievienot lietotātju";
$_['user_title_edit']					 		 = "Labot lietotātju";

$_['setting_title']						 		 = "Uzstādījumi";
$_['settings_company_name']						 = "Uzņēmuma nosaukums";
$_['settings_issue_numbering']					 = "Pieteikumu numerācija sērija";
$_['settings_logo']						 		 = "Uzņēmuma logo";
$_['setting_currency']						 	 = "Valūta";
$_['setting_favico']						 	 	 = "Favicon";
$_['settings_delete_logo']					     = "Vai tiešām vēlaties dzēst logo bildi?";
$_['settings_delete_favico']					     = "Vai tiešām vēlaties dzēst Favico bildi?";

$_['setting_app_name']						 	 = "Aplikācijas nosaukums";
$_['setting_no_reply_email']						 = "No_reply e-pasts";
$_['setting_contact_us_email']					 = "Sazinies ar mums e-pasts";
$_['setting_vat_label']							 = "PVN likme";

//------- FileStorage
$_['storage_file']								 = "Fails";
$_['storage_msg1']								 = "veiksmīgi ielādēts!";
$_['storage_msg2']								 = "netika ielādēts, mēģiniet vēl!";
$_['storage_msg3']								 = "Vai tiešām vēlaties dzēst šo failu?";
$_['storage_msg4']					 			 = "Fails veiksmīgi izdzēsts";
$_['storage_msg5']					 			 = "Kļūda dzēšot failu, mēģiniet vēl!";


//------- Stock
$_['stock_item_name']					 		 = "Nosaukums";
$_['stock_item_code']					 		 = "Kods";
$_['stock_item_group']							 = "Vienības grupa";
$_['stock_item_col1']					 		 = "N.p.k.";
$_['stock_item_title']					 		 = "Vienības";
$_['stock_item_title_add']						 = "Pievienot vienību";
$_['stock_item_title_edit']					 	 = "Labot vienību";
$_['stock_item_popup_group']						 = "-- Grupa --";
$_['stock_item_popup_name']						 = "Vienības nosaukums";
$_['stock_item_popup_col1']						 = "Vienības nos.";
$_['stock_item_popup_col2']						 = "Vienības grupa";
$_['stock_item_popup_col3']						 = "Kods";
$_['stock_item_popup_add_title']					 = "Jauna vienība";

$_['stock_group_name']					 		 = "Nosaukums";
$_['stock_group_active']					 		 = "Aktīvs";
$_['stock_group_descript']						 = "Apraksts";
$_['stock_group_col1']						     = "N.p.k.";
$_['stock_group_title']					 		 = "Vienību grupas";
$_['stock_group_title_add']					 	 = "Pievienot vienību grupu";
$_['stock_group_title_edit']					 	 = "Labot vienību grupu";

$_['stock_stockitem']					 		 = "Vienība";
$_['stock_quantity']					 			 = "Daudzums";
$_['stock_addDate']					 			 = "Pievienots noliktavai";
$_['stock_instock']					 			 = "Pieejams";
$_['stock_purchaseprice']					 	 = "Iepirkuma cena";
$_['stock_saleprice']					 		 = "Pārdošanas cena";
$_['stock_description']					 		 = "Piezīmes";
$_['stock_stock_stockitems']					 	 = "Vienības";
$_['stock_lastedit']					 			 = "Pēdējais labojums";
$_['stock_items_used_issuetickets']			 	 = "Vienība izmantota servisa pieteikumos";
$_['stock_title']					 			 = "Noliktava";
$_['stock_rack']									 = "Plaukts";
$_['stock_group']					 			 = "-- Grupa --";
$_['stock_search1']					 			 = "Vienības nos.";
$_['stock_search2']					 			 = "Pievienienots no";
$_['stock_search3']					 			 = "Pievienots līdz";
$_['stock_search4']					 			 = "Noliktavā";
$_['stock_search5']					 			 = "Vienības grupa";
$_['stock_add_new_item']					 		 = "Jauna vienība noliktavā";
$_['stock_col1']					 			     = "Vienība";
$_['stock_col2']					 				 = "Grupa";
$_['stock_col3']					 				 = "Daudzums";
$_['stock_col4']					 				 = "Pieejams";
$_['stock_col5']					 				 = "Iepirk. cena";
$_['stock_col6']					 				 = "Pārd. cena";
$_['stock_col7']					 				 = "Piev. nol.";
$_['stock_title_new']					 		 = "Jauna vienība noliktavā";
$_['stock_title_view']					 		 = "Vienība noliktavā";
$_['stock_issue_num']					 		 = "Servisa num.";
$_['stock_title_edit']					 		 = "Labot vienību noliktavā";
$_['stock_msg1']					 				 = "Datumam";
$_['stock_msg2']					 				 = "jābūt sastādītam formātā dd/mm/yyyy";
$_['stock_mod_title']					 		 = "Vienības noliktavā";
$_['stock_sale_price_total']						 = "Kopā:";

//------- Soap
$_['soap_msg1']									 = "Pieslēgums veiksmīgs";
$_['soap_msg2']									 = "Nepareizs servisa pieteikuma numurs vai parole!";
$_['soap_msg3']									 = "Nepareizs WS lietotāja vārds vai parole";

//------- Reports
$_['reports_rep1']								 = "Servisa pieteikumu kopsavilkums";
$_['reports_rep2']								 = "Visi servisa pieteikumi";
$_['reports_rep3']								 = "Servisa pieteikumi servisos";
$_['reports_rep4']					 			 = "Naudas kopsavilkums";
$_['reports_rep5']								 = "Servisa pieteikumi pa dienām servisos";
$_['reports_rep6']								 = "Nauda pa servisiem un meistariem";
$_['reports_col1']					 			 = "Serv. num.";
$_['reports_col2']								 = "Pieņ. dat.";
$_['reports_col3']								 = "Klients";
$_['reports_col4']								 = "Iekārtas nos.";
$_['reports_col5']								 = "Garantija";
$_['reports_col6']								 = "Statuss";
$_['reports_col7']								 = "Prioritāte";
$_['reports_col8']								 = "Rem. beig. dat.";
$_['reports_col9']								 = "Serviss";
$_['reports_col10']								 = "Meistars";
$_['reports_col11']								 = "Prov. izm.";
$_['reports_col12']								 = "Pakalp. cena";
$_['reports_col13']								 = "Detaļu cena";
$_['reports_col14']								 = "Nosaukums";
$_['reports_col15']								 = "Servisa pieteikumi:";
$_['reports_col16']								 = "Kopā:";
$_['reports_date_form']							 = "Datums no";
$_['reports_date_to']							 = "Datums līdz";
$_['reports_price_from']							 = "Cena no";
$_['reports_price_to']							 = "Cena līdz";
$_['reports_not_found']							 = "Nekas netika atrasts";
$_['reports_costs1']								 = "Provizoriskās izmaksas";
$_['reports_costs2']								 = "Cena par pakalpojumu";
$_['reports_costs3']								 = "Cena par detaļām";
$_['reports_costs4']								 = "Prov. izm.";
$_['reports_costs5']								 = "Cena par pakalp.";
$_['reports_title']								 = "Atskaites";
$_['reports_title2']								 = "Kopsavilkums";
$_['reports_title3']								 = "Servisa pieteikumu atskaite";
$_['reports_ddl1']								 = "-- Tips --";
$_['reports_ddl2']								 = "Fiziska pers.";
$_['reports_ddl3']								 = "Juridiska pers.";
$_['reports_ddl4']								 = "-- Veids --";
$_['reports_ddl5']								 = "-- Serviss --";
$_['reports_ddl6']								 = "-- Statuss --";
$_['reports_ddl7']								 = "-- Prioritāte --";
$_['reports_ddl8']								 = "-- Meistars --";
$_['reports_ddl9']								 = "Garantija'";

//------- Messages
$_['messages_title']								 = "Ziņojumi";
$_['messages_inbox']								 = "Iesūtne";
$_['messages_sent']								 = "Nosūtne";
$_['messages_deleted']							 = "Miskaste";
$_['messages_write_new']							 = "RAKSTĪT";
$_['messages_add_sender']						 = "Pievienot saņēmēju";
$_['messages_btn_send']							 = "Sūtīt";
$_['messages_btn_back']							 = "Atpakaļ";
$_['messages_btn_reply']							 = "Atbildēt";
$_['messages_btn_delete']						 = "Dzēst";
$_['messages_from']								 = "No";
$_['messages_to']								 = "Kam";
$_['messages_subject']							 = "Temats";
$_['messages_message']							 = "Ziņa";
$_['messages_message2']							 = "Jūsu ziņa";
$_['messages_for_admins']						 = "ADMINIEM";
$_['messages_orig_msg']							 = "Oriģinālā ziņa";
$_['messages_date']								 = "Datums";
$_['messages_admins']							 = "Administratori";

//------- Libraries
$_['lib_acl_msg']								 = "Lapa Jums nav pieejama!";
$_['lib_ticket_add_log']							 = "Pievienots servisa uzdevums";
$_['lib_ticket_edit_log']						 = "Labots servisa uzdevums";
$_['lib_ticket_delete_log']						 = "Dzēsts servisa uzdevums";
$_['lib_ticket_comments']						 = "Komentāri";
$_['lib_ticket_com_msg1']						 = "Jūsu servisam piešķirts pieteikums";
$_['lib_ticket_com_msg2']						 = "Labdien!<br/> Jūsu servisam uz remontu ir nodots servisa pieteikums";
$_['lib_ticket_change_status_log']				 = "Nomainīts statuss servisa uzdevumam";
$_['lib_user_activity_form']						 = "no";
$_['lib_user_activity_to']						 = "uz";
$_['lib_pers_legal']								 = "Juridiska pers.";
$_['lib_pers_phisical']							 = "Fiziska pers.";
$_['lib_pers_payment1']							 = "Priekšapmaksa";
$_['lib_pers_payment2']							 = "Pēcapmaksa";
$_['lib_pers_add_log']							 = "Pievienots klients";
$_['lib_pers_edit_log']							 = "Labots klients";
$_['lib_pers_delete_log']						 = "Dzēsts klients";

$_['lib_corr_msg1']								 = "Pabeigts remonts";
$_['lib_corr_msg2']								 = "Sveicināti!<br /> &nbsp;&nbsp;&nbsp;&nbsp;Vēlamies informēt, ka Jūsu iekārta, <b>";
$_['lib_corr_msg3']								 = "</b>, ir sagatavota atdošanai un ir saņemama mūsu servisā:";
$_['lib_corr_msg4']								 = ", adrese:";
$_['lib_corr_msg5']								 = "Remonta izmaksas:";
$_['lib_corr_sms1']								 = "Sveicinati! Jusu iekarta";
$_['lib_corr_sms2']								 = "ir gatava sanemsanai servisa";
$_['lib_corr_sms3']								 = "Remonta izmaksas:";
$_['lib_corr_2msg1']								 = "Servisa pieteikuma numurs:";
$_['lib_corr_2msg2']								 = "Sveicināti!<br /> &nbsp;&nbsp;&nbsp;&nbsp;Vēlamies informēt, ka Jūsu iekārta, <b>";
$_['lib_corr_2msg3']								 = "</b>, ir pieņemta  mūsu servisā:";
$_['lib_corr_2msg4']								 = "adrese:";
$_['lib_corr_2msg5']								 = "Pilnu informāciju par Jūsu iekārtas remontu varat apskatīt mūsu mājas lapā, pēc saites:";
$_['lib_corr_2msg6']								 = "Servisa pieteikuma numurs:";
$_['lib_corr_2msg7']								 = "Parole:";
$_['lib_corr_2sms1']								 = "Sveicinati! Jusu iekarta ir pienemta";
$_['lib_corr_2sms2']								 = " Vairak informacija";

//------- Persons
$_['persons_cast0']								 = "Personas tips";
$_['persons_cast1']								 = "Fiziska pers.";
$_['persons_cast2']								 = "Juridiska pers.";
$_['persons_position']							 = "Amats";
$_['persons_name']								 = "Vārds";
$_['persons_paymenttype']						 = "Apmaksas veids";
$_['persons_lastname']							 = "Uzvārds";
$_['persons_serviceperiod']						 = "Servisa periods";
$_['persons_code']								 = "Personas kods";
$_['persons_adres']								 = "Adrese";
$_['persons_type']								 = "Tips";
$_['persons_email']								 = "E-pasts";
$_['persons_description']						 = "Apraksts";
$_['persons_comp_name']							 = "Uzņēmuma nosaukums";
$_['persons_home_page']							 = "Mājas lapa";
$_['persons_reg_num']							 = "Reģistrācijas nr.";
$_['persons_vat_num']							 = "PVN nr.";
$_['persons_delete_msg']							 = "Vai tiešām vēlaties dzēst ierakstu?";
$_['persons_paymenttype1']						 = "Priekšapmaksa";
$_['persons_paymenttype2']						 = "Pēcapmaksa";
$_['persons_last_modify']						 = "Pēdējais labojums";
$_['persons_tab_phones']							 = "Tālruņi";
$_['persons_tab_contacts']						 = "Kontakti";
$_['persons_tab_accounts']						 = "Uzņēmumi";
$_['persons_tab_issuetickets']					 = "Servisa pieteikumi";
$_['persons_mod_contacts_title']					 = "Kontakti";
$_['persons_mod_contacts_title2']				 = "Uzņēmumi";
$_['persons_mod_contacts_title3']				 = "Klienti";
$_['persons_mod_tab1']							 = "Jauna fiziska pers.";
$_['persons_mod_tab2']							 = "Jauna juridiskā pers.";
$_['persons_mod_primary_phone']					 = "Primārais tālrunis";
$_['persons_ddl_kind']							 = "-- Veids --";
$_['persons_ddl_type']							 = "-- Tips --";
$_['persons_ddl_business_type']					 = "-- Līg. veids --";
$_['persons_ddl_cast0']							 = "-- Pers. tips --";
$_['persons_ddl_cast1']							 = "Fiziska pers.";
$_['persons_ddl_cast2']							 = "Juridiska pers.";
$_['persons_search_name']						 = "Nosaukums";
$_['persons_search_reg_nr']						 = "Reģ. numurs";
$_['persons_search_phone']						 = "Tālrunis";
$_['persons_new_client']							 = "Jauns klients";
$_['persons_short_phone']						 = "Primārais tālr.";
$_['persons_modal_add']							 = "Pievienot";
$_['persons_modal_comapny']						 = "Uzņēmums";
$_['persons_contact']							 = "Kontakts";
$_['persons_phone_phone']						 = "Tālrunis";
$_['persons_phone_number']						 = "Numurs";
$_['persons_phone_primary']						 = "Primārais";
$_['persons_ticket_number']						 = "Servisa num.";
$_['persons_ticket_add_date']					 = "Pieņemšanas dat.";
$_['persons_ticket_client']						 = "Klients";
$_['persons_ticket_unit']						 = "Iekārta";
$_['persons_ticket_service']						 = "Serviss";
$_['persons_ticket_status']						 = "Statuss";
$_['persons_ticket_priority']					 = "Prioritāte";
$_['persons_ticket_contactperson']				 = "Kontaktpersona";
$_['persons_ticket_repair_end_date']				 = "Remonta beigu dat.";
$_['persons_phone_msg']							 = "Pirms atvērt jaunu saglabājiet esošo!";
$_['persons_phone_new_phone']					 = "Jauns tālrunis";
$_['persons_phone_number']						 = "Tālruņa numurs";
$_['persons_phone_primary']						 = "Primārais";
$_['persons_phone_msg2']				    	 	 = "Pirms atvērt jaunu saglabājiet esošo!";
$_['persons_phone_edit_phone']					 = "Labot tālruni";
$_['persons_new_contact']						 = "Jauns kontakts";
$_['persons_edit_contact']						 = "Labot kontaktu";
$_['persons_name_lastname']						 = "Vārds Uzvārds";
$_['persons_new_company']						 = "Jauns uzņēmums";
$_['persons_edit_company']						 = "Labot uzņēmumu";
$_['persons_tab_business_types']					 = "Līguma veids";
$_['persons_business_types_name']				 = "Līguma veids";
$_['persons_business_types_description']			 = "Apraksts";
$_['persons_modal_business_types_name']			 = "Līguma veids";
$_['persons_modal_business_types_description']	 = "Apraksts";


//------- Activitys
$_['activitys_mod_title']						 = "Aktivitāte";

$_['activitys_activity_type_name']				 = "Veids";
$_['activitys_set_start_date']					 = "Iestatīt atgādinājumu";
$_['activitys_start_date']						 = "Datums";
$_['activitys_show_in_dashboard']				 = "Rādīt sākumā";
$_['activitys_assigned_to_user']					 = "Atbildīgias darbinieks";
$_['activitys_assigned_to_user_short']			 = "Atb. darbinieks";
$_['activitys_description']						 = "Apraksts";
$_['activitys_tab_title']						 = "Aktivitātes";
$_['activitys_add_activity']						 = "Pievienot aktivitāti";
$_['activitys_delete_msg']						 = "Vai tiešām vēlaties dzēst aktivitāti?";
$_['activitys_dashboard_title']					 = "Manas aktivitātes";
$_['activitys_object']					         = "Attiecas uz";

$_['activity_dash_col1']							 = "";
$_['activity_dash_col2']							 = "Datums";
$_['activity_dash_col3']							 = "Attiecas";
$_['activity_dash_col4']							 = "Aktiv. veids";
$_['activity_dash_col5']							 = "Apraksts";


//------- IssueTickets
$_['issueticket_number']							 = "Servisa numurs";
$_['issueticket_status']							 = "Statuss";
$_['issueticket_add_date']						 = "Saņemšanas datums";
$_['issueticket_priority']						 = "Prioritāte";
$_['issueticket_client']							 = "Klients";
$_['issueticket_service']						 = "Serviss";
$_['issueticket_contactperson']					 = "Kontaktpersona";
$_['issueticket_repair_user']					 = "Remonta meistars";
$_['issueticket_warranty']						 = "Garantija";
$_['issueticket_repairprice']					 = "Provizoriskās izmaksas";
$_['issueticket_serialnumber']					 = "Seriālais numurs";
$_['issueticket_serviceprice']					 = "Cena par pakalpojumu";
$_['issueticket_brand']							 = "Marka";
$_['issueticket_detailsprice']					 = "Cena par detaļām";
$_['issueticket_model']							 = "Modelis";
$_['issueticket_sendemail']						 = "Sūtīt E-pastus";
$_['issueticket_end_date']						 = "Remonta beigu datums";
$_['issueticket_send_sms']						 = "Sūtīt SMS";
$_['issueticket_defect']							 = "Defekts";
$_['issueticket_description']					 = "Piezīmes";
$_['issueticket_description_small']				 = "Redzams klientam";
$_['issueticket_delete_msg']						 = "Vai tiešām vēlaties dzēst ierakstu?";
$_['issueticket_print']				   	 		 = "Drukāt PA";
$_['issueticket_price_change_history']			 = "Izmaiņu vēsture";
$_['issueticket_last_edit']						 = "Pēdējais labojums";
$_['issueticket_title_tab1']						 = "Statusa maiņa un komentāri";
$_['issueticket_title_tab2']						 = "Izmantotās vienības";
$_['issueticket_title_tab3']						 = "Nosūtītā korespondence";
$_['issueticket_title_tab4']						 = "Bildes";
$_['issueticket_add_files']						 = "Pievienot failus";
$_['issueticket_chouse_file']					 = "Izvēlieties failu";
$_['issueticket_add_file']						 = "Pievienot";
$_['issueticket_file_comment']					 = "Komentārs";
$_['issueticket_price_change_title1']			 = "Provizorisko izmaksau izmaiņu vēsture";
$_['issueticket_price_change_title2']			 = "Cena par pakalpojumu izmaiņu vēsture";
$_['issueticket_price_change_title3']			 = "Cena par detaļām izmaiņu vēsture";
$_['issueticket_price_change_value']				 = "Vērtība";
$_['issueticket_price_change_time']				 = "Laiks";
$_['issueticket_price_change_user']				 = "Lietotājs";
$_['issueticket_modal_stauts_title']				 = "Statusa maiņa un komentāri";
$_['issueticket_modal_status_comments']			 = "Komentāri";
$_['issueticket_modal_coresp_title']				 = "Sūtīt korespondenci";
$_['issueticket_modal_coresp_ddl1']				 = "Servisa pieteikums Pievienots E-pasts";
$_['issueticket_modal_coresp_ddl2']			 	 = "Servisa pieteikums Pievienots SMS";
$_['issueticket_modal_coresp_ddl3']				 = "Servisa pieteikums Gatavs E-pasts";
$_['issueticket_modal_coresp_ddl4']				 = "Servisa pieteikums Gatavs SMS";
$_['issueticket_modal_coresp_ddl5']				 = "Servisa pieteikums brīvā forma E-pasts";
$_['issueticket_modal_coresp_ddl6']				 = "Servisa pieteikums brīvā forma SMS";
$_['issueticket_modal_coresp_subject']			 = "Temats";
$_['issueticket_modal_coresp_msg']				 = "Ziņa";
$_['issueticket_modal_coresp_send']				 = "Sūtīt";
$_['issueticket_modal_stock_title']				 = "Vienības noliktavā";
$_['issueticket_title']							 = "Serviss";
$_['issueticket_ddl_service']					 = "-- Serviss --";
$_['issueticket_ddl_status']						 = "-- Statuss --";
$_['issueticket_ddl_priority']					 = "-- Prioritāte --";
$_['issueticket_ddl_client']						 = "-- Kl. veids --";
$_['issueticket_ddl_cast0']						 = "-- Kl. tips --";
$_['issueticket_ddl_cast1']						 = "Fiziska pers.";
$_['issueticket_ddl_cast2']						 = "Juridiska pers.";
$_['issueticket_search_col1']					 = "Serv. num.";
$_['issueticket_search_col2']					 = "Seriāl. num.";
$_['issueticket_search_col3']					 = "Klienta nos.";
$_['issueticket_search_col4']					 = "Primārais tālr.";
$_['issueticket_search_col5']					 = "Pieņ. dat. no";
$_['issueticket_search_col6']					 = "Rem. beig. no";
$_['issueticket_search_col7']					 = "Pieņ. dat. līdz";
$_['issueticket_search_col8']					 = "Rem. beig. līdz";
$_['issueticket_new_app']						 = "Jauns pieteikums";
$_['issueticket_list_col1']						 = "Servisa num.";
$_['issueticket_list_col2']						 = "Pieņemšanas dat.";
$_['issueticket_list_col3']						 = "Iekārta";
$_['issueticket_list_col4']						 = "Remonta beigu dat.";
$_['issueticket_view_title']						 = "Servisa uzdevums";
$_['issueticket_date']							 = "Datums";
$_['issueticket_user']							 = "Darbinieks";
$_['issueticket_stock_title']					 = "Jauna noliktavas vienība";
$_['issueticket_stock_msg']						 = "Vai tiešām vēlaties dzēst ierakstu? Vienība tiks atgriezta noliktavā.";
$_['issueticket_coresp_new']						 = "Jauna korespondence";
$_['issueticket_coresp1']						 = "Saņēmējs";
$_['issueticket_coresp2']						 = "Temats";
$_['issueticket_coresp3']						 = "Ziņa";
$_['issueticket_coresp4']						 = "Veids";
$_['issueticket_coresp5']						 = "Nosūtīts";
$_['issueticket_coresp6']						 = "Datums";
$_['issueticket_load_files']						 = "Failu pārlāde...";
$_['issueticket_stock_add_msg']					 = "Pirms atvērt jaunu saglabājiet esošo!";
$_['issueticket_stock_add_new']					 = "Jauna vienība";
$_['issueticket_stock_add_item']					 = "Vienība";
$_['issueticket_stock_add_quantity']				 = "Daudzums";
$_['issueticket_stock_add_pprice']				 = "Iepirkuma cena";
$_['issueticket_stock_add_sale_price']			 = "Pārdošanas cena";
$_['issueticket_stock_add_desc']					 = "Piezīmes";
$_['issueticket_stock_add_msg2']					 = "Pirms atvērt jaunu saglabājiet esošo!";
$_['issueticket_stock_add_edit']					 = "Labot vienību";
$_['issueticket_stock_add_msg3']					 = "Vienībai jābūt norādītai!";
$_['issueticket_stock_add_msg4']					 = "Daudzumam jābūt ievadītam!";
$_['issueticket_stock_add_msg5']					 = "Daudzums nevar būt 0!";
$_['issueticket_stock_add_msg6']					 = "Daudzums jābūt lielākam par 0!";
$_['issueticket_stock_add_msg7']					 = "Daudzums pārsniedz šīs preces-iepirkuma pāri noliktavā. Pieejams";
$_['issueticket_stock_add_msg8']					 = "Pārdošanas cenai jābūt ievadītai!";
$_['issueticket_stock_add_msg9']					 = "Pārdošanas cenai jābūt pozitīvam ciparam!";
$_['issueticket_title_new']						 = "Jauns servisa uzdevums";
$_['issueticket_title_edit']						 = "Labot servisa uzdevumu";
$_['issueticket_date_check_1']					 = "Datumam";
$_['issueticket_date_check_2']					 = "jābūt sastādītam formātā dd/mm/yyyy";
$_['issueticket_coresp_change_msg1']				 = "Servisa uzdevumam jābūt statusā Gatavs!";
$_['issueticket_coresp_change_msg2']				 = "Epasts veiksmīgi nosūtīts!";
$_['issueticket_coresp_change_msg3']				 = "Klients nevēlās saņemt epastus!";
$_['issueticket_coresp_change_msg4']				 = "SMS veiksmīgi nosūtīta!";
$_['issueticket_coresp_change_msg5']				 = "Klients nevēlās saņemt SMS!";
$_['issueticket_coresp_change_msg6']				 = "Kļūda sūtot ziņojumus";
$_['issueticket_coresp_change_msg7']				 = "Ziņojumu sūtīšana";
$_['issueticket_ch_status_msg1']					 = "Gatavs";
$_['issueticket_ch_status_msg2']					 = "Cena par pakalpojumu";
$_['issueticket_ch_status_msg3']					 = "Cena par detaļām'";
$_['issueticket_ch_status_msg4']					 = "un 'Cena par detaļām'";
$_['issueticket_ch_status_msg5']					 = "Kļūda nomainot servisa uzdevuma statusu";
$_['issueticket_ch_status_msg6']					 = "Servisa uzdevuma statusu var nomainīt uz 'Gatavs' ja ir ievadīta";
$_['issueticket_ch_status_msg7']					 = "Servisa uzdevuma statusa maiņa";
$_['issueticket_ch_status_msg8']					 = "Servisa uzdevuma statuss nomainīts veiksmīgi!";

$_['issueticket_print_title']					 = "Pieņemšanas / nodošanas akts";
$_['issueticket_print_header']					 = "Izstrādājuma reģistrācijas veidlapa";
$_['issueticket_print_nr']					 	 = "Nr.";
$_['issueticket_print_add_date']					 = "Pieņ. datums";
$_['issueticket_print_short_phone']				 = "tel.";
$_['issueticket_print_phone']					 = "Telefona Nr.";
$_['issueticket_print_service']					 = "Servisa nodaļa";
$_['issueticket_print_warranty']					 = "Garantijas remonts";
$_['issueticket_print_service_email']			 = "Servisa epasts";
$_['issueticket_print_service_phone']			 = "Servisa tālr.";
$_['issueticket_print_service_work_time']		 = "Servisa darbalaiks";
$_['issueticket_print_phuraceprice']				 = "Provizoriskās izmaksas";
$_['issueticket_print_service_address']			 = "Servisa adrese";
$_['issueticket_print_repair_to']				 = "Plānotais remonts līdz";
$_['issueticket_print_user']					 	 = "Izstrādājumu pieņēma";
$_['issueticket_print_check_msg1']				 = "Remonta statusu var pārbaudīt šeit:";
$_['issueticket_print_check_msg2']				 = "Servisa Nr.";
$_['issueticket_print_check_msg3']				 = "Parole";
$_['issueticket_print_body']					     = '<table width="567" border="0">
                                                          <tr>
                                                            <td width="50%" rowspan="21" valign="bottom"><h2>Apkalpošans nosacījumi</h2>
                                                              <div class="legal small">
                                                                <p> Pateicamies, ka izvēlējāties mūs un uzticējāt mums  remontēt savu tehnikas vienību. Mēs centīsimies veikt Jūsu tehnikas vienībai  nepieciešamos darbus iespējami īsākā laikā, tomēr reāli nepieciešamais laiks ir  atkarīgs no gadalaika, nepieciešamo detaļu pieejamības un kopējā remontā nodoto  ierīču skaita. <br>
                                                                </p>
                                                                <p>Lai pieprasītu garantijas remontu, nododot  izstrādājumu remontā, uzrādiet iegādi apliecinošu dokumentu un garantijas  talonu. Ja Jums ierīces nodošanas brīdī nav līdzi iegādi apliecinošs dokuments  un/vai garantijas talons, bet varat to uzrādīt zināmā laika sprīdī pēc ierīces  nodošanas, lūdzu, informējiet mūs, ka ierīcei vēl spēkā garantija. Pretējā  gadījumā Jums būs jāsedz remonta izdevumi.</p>
                                                                <p><br>
                                                                  Ja atteiksieties no remonta veikšanas, Jūsu  pienākums ir segt diagnostikas izmaksas, tomēr [company_name] ir tiesības pieprasīt  no Klienta samaksu arī par jau veiktajiem remontdarbiem. </p>
                                                                <p>Jūs apņematies 20 dienu laikā no attiecīgā  paziņojuma (par tehnikas remonta beigām) saņemšanas (SMS, e-pasts vai telefona  zavans) izņemt savu ierīci no servisa centra.</p>
                                                                <p>Ja tas netiek veikts, pēc 20  dienu laika posma Jums tiks aprēķināta papildus samaksa 1 [app_currency] apmērā par katru  uzglabāšanas dienu. Tehnikas vienības, kas netiek izņemtas no servisa centra 60  dienu laikā pēc paziņojuma par tehnikas vienības remonta beigām, tiks  uzskatītas par pamestām.<br>
                                                                </p>
                                                                <p class="middle">&nbsp;</p>
                                                              </div></td>
                                                            <td width="50%" rowspan="21" valign="top"><div class="legal small"><p>&nbsp;</p>
                                                              <p><br>
                                                                <br>
                                                                Tādejādi mēs paturam tiesības bez iepriekšēja  paziņojuma pārdot vai citādi izmantot šādus izstrādājumus par saprātīgu  samaksu, atvelkot servisa centram pienākošos samaksas apjomu par diagnostiku  un/vai remontdarbu veikšanu no saņemtās summas bez jebkādas kompensācijas  īpašniekam.</p>
                                                              <p><br>
                                                            Ar šo dodu atļauju veikta manas tehnikas vienības apkopi  un/vai remontu. Ar apkalpošanas nosacījumiem esmu iepazinies un tiem piekrītu.  Ja mainīšu savu lēmumu attiecībā uz izstrādājuma remontu (pirms izstrādājuma  remonta pabeigšanas pilnībā), apņemos maksāt diagnostikas izmaksas un citas  reālās izmaksas, ja man tādas jāsedz saskaņā ar nosacījumiem. Esmu saņēmis šīs  veidlapas eksemplāru, kurā ietverti arī apkalpošanas nosacījumi.<span class="middle"><br>
                                                            <br>
                                                            Klienta paraksts: ............................................</span></p>
                                                              <p>&nbsp;</p>
                                                              <p>Apliecinu, ka esmu saņēmis savu tehnikas vienību atpakaļ, pretenziju nav.<br>
                                                                Klienta paraksts par saņemšanu</p>
                                                              <p><span class="middle">Klienta paraksts: ............................................</span></p>
                                                              <p>&nbsp;</p>
                                                            </div></td>
                                                          </tr>
                                                        </table>';













?>
