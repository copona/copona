<?php
$_['heading_title'] = 'Pasūtījuma noformēšana';
$_['heading_title2'] = 'Apstiprināt pasūtījumu';
$_['text_agree'] = 'Esmu izlasījis(usi) sadaļu <a class="fancybox" href="%s" alt="%s"><b>%s</b></a> un piekrītu minētiem noteikumiem';
$_['text_total_title'] = 'Kopā';
$_['text_shipping'] = 'Piegāde ar PVN';
$_['text_total_payment'] = 'Kopā apmaksai';
$_['text_price'] = 'Cena ar PVN';
$_['text_total'] = 'Kopā ar PVN';
$_['text_shipping_method'] = 'Piegādes veids';
$_['text_shipping_address'] = 'Piegādes adrese';
$_['text_payment_method'] = 'Apmaksas veids';
$_['entry_company'] = 'Uzņēmums:';
$_['text_contact_buyer'] = 'Pircēja kontakti:';
$_['entry_firstname'] = 'Vārds';
$_['entry_lastname'] = 'Uzvārds';
$_['text_surname'] = 'Uzvārds';
$_['entry_telephone'] = 'Mob.tel.';
$_['entry_email'] = 'E-pasts';
$_['text_company_name'] = 'Uzņēmuma nosaukums';
$_['entry_company_id'] = 'Reģistrācijas numurs';
$_['entry_tax_id'] = 'PVN numurs';
$_['entry_address_2'] = 'Juridiskā adrese';
$_['entry_city'] = 'Pilsēta';
$_['entry_country'] = 'Valsts';
$_['entry_address_1'] = 'Adrese';
$_['error_form'] = '<a href="/index.php?route=account/login">Reģistējies</a> vai turpini kā nereģistrēts lietotājs.';
$_['error_shipping_method_choose_shop'] = 'Izvēlieties veikalu, kurā vēlaties saņemt preci!';
$_['text_make_order'] = 'Turpināt';
$_['cart_login'] = 'Neesi vēl reģistrējies? Spied <a href="%s">šeit</a> lai autorizētos vai <a href="%s">šeit</a> lai reģistrētos!';
$_['error_stock'] = '*** Produkti vēlamajā daudzumā nav pieejami noliktavā!';

$_['customer_group_fiz_pers'] = "Privātpersona";
$_['customer_group_jur_pers'] = "Uzņēmums";

$_['payer_data_title'] = "Maksātāja dati";
$_['entry_company_name'] = "Uzņēmuma nosaukums";
$_['entry_reg_num'] = "Reģistrācijas numurs";
$_['entry_vat_num'] = "PVN numurs";
$_['entry_bank_name'] = "Bankas nosaukums";
$_['entry_bank_code'] = "Bankas kods";
$_['entry_bank_account'] = "Bankas konts";
$_['entry_address_2'] = "Juridiskā adrese";


?>



