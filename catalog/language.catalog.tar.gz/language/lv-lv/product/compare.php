<?php
$_['heading_title'] = 'Preču salīdzināšana';
$_['text_product'] = 'Preču informācija';
$_['text_name'] = 'Prece';
$_['text_image'] = 'Attēls';
$_['text_price'] = 'Cena';
$_['text_model'] = 'Modelis';
$_['text_manufacturer'] = 'Zīmols';
$_['text_availability'] = 'Pieejamība';
$_['text_instock'] = 'Ir pieejams';
$_['text_rating'] = 'Vērtējums';
$_['text_reviews'] = 'Balstīts uz %s atsauksmēm.';
$_['text_summary'] = 'Anotācija';
$_['text_weight'] = 'Svars';
$_['text_dimension'] = 'Izmēri (G x P x A)';
$_['text_remove'] = 'Dzēst';
$_['text_compare'] = 'salīdzināt produktus (%s)';
$_['text_success'] = 'Tu veiksmīgi pievienoji <a href="%s">%s</a> <a href="%s"><strong>salīdzinājuma sarakstam</strong></a>!';
$_['text_empty'] = 'Jūs neesat pievienojuši nevienu preci salīdzināšanai.';
$_['button_continue'] = 'Aizvērt logu';
?>