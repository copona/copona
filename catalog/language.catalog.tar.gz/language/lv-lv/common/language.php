<?php
$_['heading_title'] = 'Valoda';
$_['entry_language'] = 'Valoda:';
$_['text_language'] = 'Valoda';
?>