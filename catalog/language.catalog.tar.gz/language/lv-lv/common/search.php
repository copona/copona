<?php
// Heading 
$_['heading_title'] = 'Meklēt';

// Text
$_['text_keywords'] = 'Atslēgvārdi';
$_['text_search_price_asc'] = 'Cenas (Zemākā > Augstākā)';
$_['text_search_price_desc'] = 'Cenas (Augstākā > Zemākā)';
$_['text_advanced'] = 'Izvērstā meklēšana';
$_['text_products'] = 'Produkti';
$_['text_search_products'] = 'Meklēšanas rezultāts preču katalogā';
$_['text_search_infos'] = 'Meklēšanas rezultāts info lapās';
$_['text_everything'] = 'Meklēt visā lapā';
$_['text_sort_by'] = 'Kārtot pēc';
$_['text_search_in_products'] = 'Meklēt preču katalogā';
$_['text_search_in_info'] = 'Meklēt info lapās';
?>
