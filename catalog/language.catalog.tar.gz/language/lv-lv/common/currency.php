<?php
$_['text_currency'] = 'Valūta';
?>