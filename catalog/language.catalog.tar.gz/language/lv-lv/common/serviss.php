<? 
 // Heading 
$_['heading_title']        = 'Servisa pieteikuma pārbaude';
$_['meta_tag_description']       = 'Servisa pieteikuma pārbaude. Iespēja tiešsaistē pārbaudīt Jūsu iesniegtās iekārtas servisa statusu, izmaksas';

$_['text_service_number']         = 'Servisa numurs';
$_['text_password']         = 'Parole';
$_['text_check']         = 'Pārbaudīt';
$_['text_service']         = 'Serviss';
$_['text_status']         = 'Statuss';
$_['text_client']         = 'Klients';
$_['text_service_aproved'] = 'Servisā pieņemts: ';
$_['text_warranty']         = 'Garantija: ';
$_['text_warranty_repair']         = 'Garantijas remonts';
$_['text_outside_warranty']         = 'Ārpus garantijas remonts';
$_['text_marka']         = 'Marka: ';
$_['text_serial']         = 'Seriālais numurs: ';
$_['text_model']         = 'Modelis: ';
$_['text_repair_date']         = 'Remonta beigu datums: ';
$_['text_defect']         = 'Defekts: ';
$_['text_updated']         = 'Pēdējoreiz atjaunots: ';
$_['text_history']         = 'Izmaiņu vēsture';
$_['text_date']         = 'Datums';
$_['text_new_status']         = 'Jaunais statuss';
$_['text_comment']         = 'Komentārs';
$_['text_price_components']         = 'Cena par detaļām: ';
$_['text_price_service']         = 'Cena par pakalpojumu: ';
$_['text_price_total']         = 'Provizoriskās izmaksas KOPĀ: ';
$_['text_added_images']         = 'Pievienotie attēli';


$_['text_Atdots']         = 'Atdots';
$_['text_Defektācija']         = 'Defektācija';
$_['text_Saskaņošana']         = 'Saskaņošana';
$_['text_Remonts']         = 'Remonts';
$_['text_Gatavs']         = 'Gatavs';
$_['text_bez']         = 'Bez';




$_['text_status_atdots']         = 'Atdots';

$_['error_check_again']         = 'Lūdzu, pārbaudiet datus un mēģiniet vēlreiz!';
$_['error_antihack_timeout']         = 'Pārāk daudz neveiksmīgu pārbaužu īsā laika periodā. Lūdzu, pārbaudiet servisa pieteikuma numuru un mēģiniet pēc 15 minūtēm!';
$_['error_antihack_toomany']         = 'Pārāk daudz neveiksmīgu mēģinājumu īsā laika periodā!';

$_['']         = '';
$_['']         = '';
$_['']         = '';

// Text
$_['text_account']         = 'Mans profils';
$_['text_create']          = 'Reģistrācija';
