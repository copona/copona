<?php
$_['text_home'] = 'Sākums';
$_['text_wishlist'] = 'Vēlmju saraksts (%s)';
$_['text_cart'] = 'Pirkumu grozs';
$_['text_items'] = '%s Prece(s) - %s';
$_['text_search'] = 'Meklēta';
$_['text_search_open'] = 'Meklēt, piemēram: Husqvarna dārza tehnika';
$_['text_welcome'] = '<a href="%s">Pieslēgties</a> vai <a href="%s">reģistrēties</a>.';
$_['text_login_link'] = 'Pieslēgties';
$_['text_register_link'] = 'Reģistrēties';
$_['text_logout_link'] = 'Iziet';
$_['text_logged'] = '<a href="%s">%s</a> (<a href="%s">iziet</a>)';
$_['text_account'] = 'Mans profils';
$_['text_checkout'] = 'Noformēt pirkumu';
$_['text_language'] = 'Valoda';
$_['text_currency'] = 'Valūta';
$_['text_shopping_cart'] = 'Iepirkumu grozs';
$_['text_free_shipping_in_latvia'] = 'Летняя акция: бесплатная доставка по всей Латвии!';
$_['text_brands_menu'] = 'Ražotāji';
$_['text_categories_menu'] = 'Kategorijas';
$_['text_register'] = 'Reģistrēties';
$_['text_login'] = 'Pieslēgties';
$_['text_all'] = ' ';
$_['text_order'] = 'Pasūtījumi';
$_['text_logout'] = 'IZIET';
$_['text_category'] = 'Izvēlne';
?>