<?php
// Heading
$_['heading_title'] = 'Kategorijas';
$_['text_price1'] = 'Maksa par vietu diennaktī';
$_['text_price2'] = 'Par vienu pieaugušo diennaktī';
$_['text_price3'] = 'Par vienu bērnu līdz 12g. diennaktī';
$_['text_product_footer'] = 'Atvērts: no 1. aprīļa līdz 31. decembrim <br> Mājiņu skaits: 8 </p>    		';


$_['text_1day'] = '1 diena';
$_['text_3days'] = '3 dienas';
$_['text_7days'] = '7 dienas';