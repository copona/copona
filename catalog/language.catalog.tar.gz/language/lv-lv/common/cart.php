<?php
$_['heading_title'] = 'Iepirkumu grozs';
$_['text_empty'] = 'Pašreiz pirkumu grozs ir tukšs!';
$_['text_cart'] = 'GROZS';
$_['text_checkout'] = 'PASŪTĪT';
$_['text_items'] = '&nbsp;(%s)  <b>%s</b>';
$_['text_short_quantity'] = 'gab';
?>