<?php
$_['text_information'] = 'Par mums';
$_['text_service'] = 'Noteikumi';
$_['text_extra'] = 'Piegādes informācija';
$_['text_account'] = 'Norēķinu veidi';
$_['text_contact'] = 'Sazinieties ar mums';
$_['text_return'] = 'Atgriezt preci';
$_['text_sitemap'] = 'Vietnes karte';
$_['text_manufacturer'] = 'Zīmols';
$_['text_voucher'] = 'Dāvanu kartes';
$_['text_affiliate'] = 'Mūsu partneriem';
$_['text_special'] = 'Īpašie piedāvājumi';
$_['text_login'] = 'Pieslēgties';
$_['text_order'] = 'Pasūtījumu vēsture';
$_['text_wishlist'] = 'Vēlmju saraksts';
$_['text_newsletter'] = 'Jaunumu izsūtne';
$_['text_terms'] = 'Noteikumi';
$_['text_powered'] = '&copy; %s %s<br />';
$_['text_copyright'] = 'Visas tiesības aizsargātas';
$_['text_contacts'] = 'Kontakti';
?>