<?php
// Heading
$_['heading_title']     = 'Tehniskā apkope';

// Text
$_['text_maintenance']  = 'Tehniskā apkope';
$_['text_message']      = '<h1 style="text-align:center;">Atvainojamies par sagādātajām neērtībām, mēs pašlaik veicam plānoto tehnisko apkopi. <br/>Būsim atpakaļ pēc iespējas ātrāk, lūdzu, atnāciet vēlāk.</h1>';
?>

