<?php
$_['heading_title'] = 'Atlasīt pēc';
?>