<?php
// Heading 
$_['heading_title'] = 'Infocategory';

// Text
$_['text_contact']  = 'Sazinaties ar mums';
$_['text_sitemap']  = 'Vietnes karte';
?>