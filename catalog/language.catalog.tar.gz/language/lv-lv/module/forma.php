<?php

/*  REMOVED
$_['heading_title'] = 'Laipni lūdzam mūsu draugu lokā!';
$_['text_firstname'] = 'Vārds';
$_['text_lastname'] = 'Uzvārds';
$_['text_phone'] = 'Tālrunis';
$_['text_address'] = 'Adrese, kurā tiks izmēģināts Automoweris';
$_['text_email'] = 'E-pasts';
$_['text_month'] = 'Vēlamais mēnesis';
$_['text_agree'] = 'Piekrītu piedāvājuma <a href="%s" target="_blank">noteikumiem</a>';

$_['text_automower_welcome'] = 'Pieteikšanās automower!';
$_['text_automower_success'] = 'Paldies par reģistrāciju! Jūs esat pieteikušies bezmaksas automower testam! <br />
Mēs ar Jums sazināsimies tuvākajā laikā!';
$_['text_may'] = 'Maijs';
$_['text_june'] = 'Jūnijs';
$_['text_july'] = 'Jūlijs';
$_['text_august'] = 'Augusts';
$_['error_form'] = 'Lūdzu, norādiet obligātos laukus.';
$_['error_antispam'] = 'Lūdzu, pārbaudiet visus ievadītos datus uzmanīgi';
$_['text_success'] = 'Paldies! Jūsu pieteikums ir saņemts! Mēs ar Jums sazināsimies tuvākajā laikā!';
*/
