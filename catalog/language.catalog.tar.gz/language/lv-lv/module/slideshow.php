<?php
// Heading 
$_['heading_title'] = '';

// Text
$_['text_read_more'] = 'lasīt vairāk';
?>