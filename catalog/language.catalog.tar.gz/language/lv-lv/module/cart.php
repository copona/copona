<?php
$_['heading_title'] = 'Iepirkumu grozs';
$_['text_items'] = '%s prece(s) - %s';
$_['text_empty'] = 'Jūsu grozs ir tukšs!';
$_['text_cart'] = 'Uz grozu';
$_['text_checkout'] = 'Pirkt';
?>