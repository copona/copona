<?php
// Heading
$_['heading_title']  = 'Valūta';

// Entry
$_['entry_currency'] = 'Valūta:';
?>