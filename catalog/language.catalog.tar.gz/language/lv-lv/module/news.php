<?php
//-----------------------------------------------------
// News Module for Opencart v1.5.6   					
// Modified by villagedefrance                          		
// contact@villagedefrance.net                         		
//-----------------------------------------------------

// Heading 
$_['heading_title']	= 'JAUNUMI';

// Text
$_['text_more']  	= 'Skatīt visus';
$_['text_posted']	= 'pievienots:';

// Buttons
$_['buttonlist']     	= 'Skatīt visus jaunumus';
?>
