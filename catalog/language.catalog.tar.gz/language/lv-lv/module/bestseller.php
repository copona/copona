<?php
$_['heading_title'] = 'Pirktākās preces';
$_['text_reviews'] = 'Balstīts uz %s atsauksmēs(m).';
$_['text_sale'] = 'Izpārdošana';
?>