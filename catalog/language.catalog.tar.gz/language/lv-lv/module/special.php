<?php
$_['heading_title'] = 'Atlaides';
$_['text_reviews'] = 'Balstīts uz %s atsauksmēs(m).';
$_['text_buy_offer'] = 'Pirkt';
$_['text_sale'] = 'Akcija';
$_['text_tax'] = 'Bez PVN: ';
?>