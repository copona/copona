<?php
// Heading
//$_['heading_title'] = 'Kategorijas';
$_['heading_title'] = 'Lampas, spuldzes, LED spuldzes, ventilatori';


// Text
$_['text_tax']      = 'Bez PVN:';