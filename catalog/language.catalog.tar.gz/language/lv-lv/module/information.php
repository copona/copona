<?php
// Heading 
$_['heading_title'] = 'Informācija';

// Text
$_['text_contact']  = 'Sazināties ar mums';
$_['text_sitemap']  = 'Vietnes karte';
?>