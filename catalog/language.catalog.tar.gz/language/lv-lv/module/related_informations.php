<?php
// Heading 
$_['heading_title'] = 'Kategorijas';

// Text
$_['text_contact']  = 'Sazinaties ar mums';
$_['text_sitemap']  = 'Vietnes karte';
$_['text_read_more']  = 'Lasit vairak �';
?>