<?php
$_['heading_title'] = 'Kategorijas';
$_['text_contact'] = 'Sazinaties ar mums';
$_['text_sitemap'] = 'Vietnes karte';
$_['text_read_more'] = 'lasīt vairāk';
?>