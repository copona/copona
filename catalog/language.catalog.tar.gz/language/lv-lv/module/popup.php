

<?php
// Heading 
$_['heading_title'] 	= 'popup';

// Text
$_['text_brands']  		= 'Brands';
$_['text_gift']			= 'Gift Vouchers';
$_['text_affiliates']	= 'Affiliates';
//$_['text_specials']		= 'Akcijas';
?>
