<?php
$_['heading_title'] = 'Jaunākās preces';
$_['text_reviews'] = 'Balstīts uz %s atsauksmēs(m).';
$_['text_sale'] = 'Akcija';
?>