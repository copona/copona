 <?php
// Heading 
$_['text_brands']        = 'Pārstāvētie zīmoli';

// Text
$_['text_partners']         = 'Sadarbības partneri';