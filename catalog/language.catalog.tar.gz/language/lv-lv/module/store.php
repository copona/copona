<?php
// Heading 
$_['heading_title'] = 'Mūsu veikali';

// Text
$_['text_default']  = 'Galvenais';
$_['text_store']    = 'Lūdzu, izvēlieties veikalu, kuru vēlaties apmeklēt.';
?>