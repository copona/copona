<?php

// Heading
$_['heading_title']  = 'Tagu mākonis';

$_['text_notags']  = 'Nav neviena taga';
$_['text_href_title']  = 'Produkti ir ietagoti ar';

?>