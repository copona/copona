<?php
// Heading 
$_['heading_title_booking'] 	  = 'Rezervācija';
$_['heading_travelDates'] = 'Iebraukšanas un izbraukšanas datumi';
$_['heading_checkIn']     = 'Iebraukšana';
$_['heading_checkOut']	  = 'Izbraukšana';

// Text
$_['text_adults']  		  = 'Pieaugušie';
$_['text_children']		  = 'Bērni';
$_['text_age1']			  = '(0 - 3 g)';
$_['text_age2']			  = '(3 - 12 g)';
$_['text_room1']	  		  = '1. Num.';
$_['text_room2']	  		  = '2. Num.';
$_['text_room3']	  		  = '3. Num.';
$_['text_addRoom']		  = '+ Pievienot vēl numuriņus';
$_['text_search']		  = 'Meklēt numuriņus';
$_['text_contacs']		  = 'Sazinieties ar mums';
?>