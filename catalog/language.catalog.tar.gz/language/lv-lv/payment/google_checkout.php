<?php
// Entry
$_['entry_postcode'] = 'Pasta indekss:';
$_['entry_country']  = 'Valsts:';
$_['entry_zone']     = 'Pilsēta / Pagasts:';
?>