<?php
// Text
$_['text_title'] = 'Kredītkarte / Debetkarte (2Checkout)';
?>