<?php
// Text
$_['text_title']           = 'Kredītkarte / Debetkarte (Authorize.Net)';
$_['text_credit_card']     = 'Kredītkartes informācija';
$_['text_wait']            = 'Lūdzu uzgaidiet!';

// Entry
$_['entry_cc_owner']       = 'Kartes īpašnieks:';
$_['entry_cc_number']      = 'Kartes Numurs:';
$_['entry_cc_expire_date'] = 'Kartes derīguma termiņš:';
$_['entry_cc_cvv2']        = 'Kartes drošības kods (CVV2):';
?>