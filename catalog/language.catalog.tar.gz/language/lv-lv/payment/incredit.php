<?php
// Text
$_['text_title']       = 'InCredit līzings';
$_['text_instruction'] = 'Līzinga pieteikuma anketa';
$_['text_payment']     = 'Sagaidiet, lūdzu, mūsu apstiprinājumu par preces pieejamību noliktavā pirms naudas pārskaitīšanas!';
$_['button_apply_for_leasing']     = 'Pieteikties līzingam';
$_['button_credit_calculator']     = 'Kredīta kalkulators';
?>