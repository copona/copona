<?php
$_['text_title'] = 'PayPal Express (ieskaitot Kredītkartes un Debetkartes)';
$_['text_cart'] = 'Iepirkumu grozs';
?>