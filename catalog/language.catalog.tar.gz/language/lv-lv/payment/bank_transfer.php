<?php
$_['text_title'] = 'Bankas pārskaitījums';
$_['text_instruction'] = 'Rēķina priekšapmaksa';
$_['text_description'] = 'Veicot norēķinus ar bankas pārskaitījumu, norādiet maksājuma uzdevumā savu <strong>pasūtījuma numuru.</strong>';
$_['text_payment'] = '<br /><br />
    <h4>Rekvizīti:</h4>';
/*$_['text_payment'] = '<br>Lai maksimāli ātri varētu veikt Jūsu pasūtījuma apstrādi, 
    ja maksājumu veicat ne no A/S SWEDBANK konta, <br>
    lūdzam atsūtīt maksājuma uzdevuma kopiju (tas var būt arī bankas neapstiprināts) uz e-pastu: <br><br>

    ';*/
?>