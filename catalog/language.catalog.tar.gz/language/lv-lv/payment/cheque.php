<?php
// Text
$_['text_title']       = 'Čeks / Naudas rīkojuma instrukcija';
$_['text_instruction'] = 'Čeks / Naudas rīkojums';
$_['text_payable']     = 'Saņēmēj: ';
$_['text_address']     = 'Adrese: ';
$_['text_payment']     = 'Pasūtījums netiks apstrādāts, kamēr nauda netiks pārskaitīta mūsu maksājuma kontā.';
?>