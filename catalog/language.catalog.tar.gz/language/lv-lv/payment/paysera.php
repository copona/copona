<?php
// Heading
$_['heading_title']      = 'Paysera';
$_['text_title'] 		 = 'Maksāšanas veidi: <img class="p-img" src="/media/payments-accepted.png" alt="Payemnts" /> u.c.';

// Text 
$_['text_payment']       = 'Maksājums';
$_['text_success']       = 'Success: Izmaiņas Pysera konta uzstādījumos saglabātas!';
$_['text_development']   = '<span style="color: red;">IZSTRĀDE</span>';
$_['text_successful']    = 'On - Vienmēr veiksmīgs';
$_['text_declined']      = 'On - Vienmēr atteikts';
$_['text_off']           = 'Izslēgts';
$_['text_response']     = 'Atbilde';
$_['text_failure']      = '... Jūsu maksājums ir atcelts!';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">Lūdzu uzgaidiet ...</span></b><br>Ja Jūs netiekat automātiski pāradresēti uz mūsu lapu 10 sekundēs, lūdzu spiediet <a href="%s">šeit</a>.';										  

      
// Entry 
$_['entry_project']      = 'Projekta ID:';
$_['entry_sign']         = 'Projekta parole:';
$_['entry_lang']     	 = 'Valoda<small>(LIT, ENG, RUS)<small>:';
$_['entry_test']         = 'Testa režīms:';
$_['entry_order_status'] = 'Pasūtījuma statuss pēc veiksmīga maksājuma:';
$_['entry_geo_zone']     = 'Geo Zona:';
$_['entry_status']       = 'Statuss:';
$_['entry_sort_order']   = 'Sort secība:';

// Help
$_['help_callback']      = '';


// Pay Method Select
$_['text_paycountry']    = 'Maksāšanas valsts';
$_['text_chosen']		 = 'Jūs esat izvēlējušies maksāt izmantojot Paysera.com';


// Error
$_['error_permission']   = 'Uzmanību: Jums nav tiesību mainīt Paysera maksājumu!';
$_['error_project']      = 'Projekta ID ir obligāts!';
$_['error_sign']     	 = 'Signature parole ir obligāta!';
$_['error_lang']     	 = 'Valodas kods ir obligāts!';
