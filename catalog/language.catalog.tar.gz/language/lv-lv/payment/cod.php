<?php
$_['text_title'] = 'Priekšapmaksa';
?>