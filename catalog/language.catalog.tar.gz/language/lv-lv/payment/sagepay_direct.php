<?php
// Text
$_['text_title']           = 'Kredītkarte / Debetkarte (SagePay)';
$_['text_credit_card']     = 'Kredītkartes informācija';
$_['text_start_date']      = '(ja pieejamas)';
$_['text_issue']           = '(tikai kartēm Maestro un Solo)';
$_['text_wait']            = 'Lūdzu, uzgaidiet!';

// Entry
$_['entry_cc_owner']       = 'Kartes īpašnieks:';
$_['entry_cc_type']        = 'Kartes tips:';
$_['entry_cc_number']      = 'Kartes numurs:';
$_['entry_cc_start_date']  = 'Karte derīga no datuma:';
$_['entry_cc_expire_date'] = 'Kartes derīguma termiņš:';
$_['entry_cc_cvv2']        = 'Kartes drošības kods (CVV2):';
$_['entry_cc_issue']       = 'Kartes izdošanas numurs:';
?>