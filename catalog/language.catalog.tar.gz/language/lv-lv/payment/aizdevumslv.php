<?php
// Text
$_['text_title']       = 'Aizdevums.lv';
$_['text_instruction'] = '<script src="http://www.aizdevums.lv/form/jquery.colorbox.js"></script> 
<link media="screen" rel="stylesheet" href="http://www.aizdevums.lv/form/colorbox.css" />

Lūdzu, aizpildiet aizdevums.lv pieteikumu: <input type="button" class="button iframe" href="http://www.aizdevums.lv/form/index.php?partCode=UVIOBS&amount=%s" value="Aizdevums.lv pieteikums"/>
<script>
$(document).ready(function(){ $(".iframe").colorbox({iframe:true, fixed:true, width:"750px", height:"90%%"}); });
</script>


';
$_['text_description'] = '';
$_['text_payment']     = '';