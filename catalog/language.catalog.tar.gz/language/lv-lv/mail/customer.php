<?php
// Text
$_['text_subject']  = '%s - Paldies par reģistrāciju.';
$_['text_welcome']  = 'Esiet laipni aicināti un paldies par reģistrāciju veikalā %s!';
$_['text_login']    = 'Jūsu profils ir veiksmīgi izveidots, tagad Jūs varat ienākt savā profilā, izmantojot savu e-pasta adresi un paroli, apmeklējot mūsu tīmekļa vietni:';

$_['text_approval'] = ''; //'Jūsu profilam ir nepieciešams apstiprinājums pirms Jūs varēsiet to lietot. Tiklīdz veikala administrācija to apstiprinās, Jūs varēsiet ienākt savā profilā, izmantojot savu e-pasta adresi un paroli, apmeklējot mūsu tīmekļa vietni:';
$_['text_services'] = 'Tagad Jūs varēsiet ātri un ērti noformēt pasūtījumus, sekot līdzi pasūtījuma apstrādei, rakstīt atsauksmes, komentēt un saņemt veikala aktuālāko informāciju savā e-pastā.';
$_['text_thanks']   = 'Ar cieņu,';
 
$_['text_new_customer']   = 'Jauns Internet veikala klients!';
$_['text_signup']         = 'Jūsu veikalā reģistrējies jauns klients:';
$_['text_website']        = 'Klienta mājas lapa:';
$_['text_customer_group'] = 'Klienta grupa:';
$_['text_firstname']      = 'Vārds:';
$_['text_lastname']       = 'Uzvārds:';
$_['text_company']        = 'Uzņēmuma nosaukums:';
$_['text_email']          = 'E-pasts:';
$_['text_telephone']      = 'Tālrunis:';
$_['text_facebook_user']      = 'Lietotājs reģistrējies ar Facebook!';
?>