<?php
// Text
$_['text_subject']         = '%s - paldies, ka reģistrējāties';
$_['text_welcome']         = 'Laipni lūdzam un paldies, ka reģistrējāties %s!';
$_['text_login']           = 'Jūsu konts ir izveidots un jūs varat pieteikties norādot savu e-pasta adresi un paroli apmeklējot mūsu vietni vai sekojošo hipersaiti:';
$_['text_approval']        = 'Jūsu kontam jābūt apstiprinātam pirms jūs varēsiet pieteikties. Tiklīdz jūsu konts tiks apstiprināts, jūs varēsiet pieteikties norādot savu e-pasta adresi un paroli apmeklējot mūsu vietni vai sekojošo hipersaiti:';
$_['text_services']        = 'Piesakoties jūs varēsiet aplūkot savu pasūtījumu vēsturi, izdrukāt rēķinus un rediģēt sava konta iestatījumus.';
$_['text_thanks']          = 'Paldies,';

?>