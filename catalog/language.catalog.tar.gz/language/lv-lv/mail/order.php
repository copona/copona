<?php
$_['text_new_subject'] = '%s - pasūtījums %s';
$_['text_new_greeting'] = 'Paldies par jūsu interesi %s piedāvātām precēm. Jūsu pasūtījums ir saņemts. Tuvākajā laikā mēs ar Jums sazināsimies.';
$_['text_new_received'] = 'Jūs esat saņēmis(usi) pasūtījumu.';
$_['text_new_link'] = 'Savu pasūtījumu varat apskatīt šeit:';

$_['text_new_order_detail'] = 'Saņēmējs';
$_['text_new_instruction'] = 'Rēķina piezīmes';
$_['text_new_invoice_no'] = 'Rēķina Nr.:';
$_['text_new_order_id'] = 'Rēķina Nr.:';
$_['text_new_date_added'] = 'Pasūtījuma datums:';
$_['text_new_order_status'] = 'Pasūtījuma stāvoklis:';
$_['text_new_payment_method'] = 'Maksājuma veids:';
$_['text_new_shipping_method'] = 'Piegādes adrese:';
$_['text_new_email'] = 'E-pasts:';
$_['text_new_telephone'] = 'Tālrunis:';
$_['text_new_ip'] = 'IP adrese:';
$_['text_new_payment_address'] = 'Maksātāja adrese';
$_['text_new_shipping_address'] = 'Piegādes adrese';
$_['text_new_products'] = 'Preces';
$_['text_new_product'] = 'Prece';
$_['text_new_model'] = 'Modelis';
$_['text_new_quantity'] = 'Daudzums';
$_['text_new_price'] = 'Cena';
$_['text_new_order_total'] = 'Pasūtījuma summa';
$_['text_new_total'] = 'Kopā';
$_['text_new_download'] = 'Tiklīdz apstiprināsies maksājums, Jūs varēsiet noklikšķināt uz norādīto saiti, lai lejupielādēt nopirkto(s) failu(s):';
$_['text_new_comment'] = 'Komentāri pie Jūsu pasūtījuma:';
//$_['text_new_footer'] = 'Lūdzu, atbildiet uz šo e-pasta ziņojumu, ja jums ir kādi jautājumi.';
$_['text_new_powered'] = 'Izstrādāts - "INDEEDD"';
$_['text_update_subject'] = '%s - Pasūtījuma izmaiņas %s';
$_['text_update_order'] = 'Pasūtījums Nr.:';
$_['text_update_date_added'] = 'Pasūtījuma datums:';
$_['text_update_order_status'] = 'Jūsu pasūtījums ir atjaunināts ar sekojošu stāvokli:';
$_['text_update_comment'] = 'Komentāri pie Jūsu pasūtījuma:';
$_['text_update_link'] = 'Savu pasūtījumu varat apskatīt šeit:';

$_['text_new_footer'] = 'Ja Jums ir kādi jautājumi, lūdzu atbildiet uz šo e-pasta ziņojumu.';




$_['text_owner_rekviziti'] = '<b></b> SIA "Datorveikals"<br />
					<b>Reģ. Nr.:</b> xxxx<br />
					<b>PVN Nr.:</b> LVxxxx<br />
					<b>Juridiskā adrese:</b> Lielā iela 38-1, Rīga , LV – 1000<br />
					<b>Bankas nosaukums:</b> AS ”Swedbank”<br />
					<b>Bankas kods:</b> HABALV22<br />
					<b>Konts:</b> LV86HABAxxxx<br />';
					
$_['text_other_info'] = '<b>Samaksas veids:</b> Priekšapmaksa<br />
					     <b>Valūta:</b> EUR<br />';
					


$_['text_order_payer'] = "Maksātājs";
$_['text_order_header'] = "Rēķina informācija";


$_['customer_group_id'] 		 = '<b>Maksātājs</b>';
$_['customer_group_id_1'] 		 = 'Fiziska persona';
$_['customer_group_id_2'] 		 = 'Juridiska persona';
$_['company_name'] 				 = '<b>Uzņēmuma nosaukums</b>';
$_['reg_num'] 					 = '<b>Reģistrācijas numurs</b>';
$_['vat_num'] 					 = '<b>PVN numurs</b>';
$_['bank_name'] 				 = '<b>Bankas nosaukums</b>';
$_['bank_code'] 				 = '<b>Bankas kods</b>';
$_['bank_account'] 				 = '<b>Konta numurs</b>'; 
$_['address_2'] 				 = '<b>Juridiskā adrese</b>';

$_['text_first_last_name']			 = 'Vārds Uzvārds';
$_['text_email']			 			 = 'E-pasts';
$_['text_phone']						 = 'Tālrunis';

$_['text_update_footer']        = 'Lūdzu, atbildiet uz šo e-pasta ziņojumu, ja Jums ir kādi jautājumi.';


/*
$_['text_new_order_detail'] = 'Pasūtījuma detalizācija';
$_['text_new_instruction'] = 'Rēķina piezīmes';
$_['text_new_invoice_no'] = 'Rēķina Nr.:';
$_['text_new_order_id'] = 'Pasūtījuma Nr.:';
$_['text_new_date_added'] = 'Pasūtījuma datums:';
$_['text_new_order_status'] = 'Pasūtījuma stāvoklis:';
$_['text_new_payment_method'] = 'Maksājuma veids:';
$_['text_new_shipping_method'] = 'Piegādes adrese:';
$_['text_new_email'] = 'E-pasts:';
$_['text_new_telephone'] = 'Tālrunis:';
$_['text_new_ip'] = 'IP adrese:';
$_['text_new_payment_address'] = 'Maksātāja adrese';
$_['text_new_shipping_address'] = 'Piegādes adrese';
$_['text_new_products'] = 'Preces';
$_['text_new_product'] = 'Prece';
$_['text_new_model'] = 'Modelis';
$_['text_new_quantity'] = 'Daudzums';
$_['text_new_price'] = 'Cena';
$_['text_new_order_total'] = 'Pasūtījuma summa';
$_['text_new_total'] = 'Kopā';
$_['text_new_download'] = 'Tiklīdz apstiprināsies maksājums, Jūs varēsiet noklikšķināt uz norādīto saiti, lai lejupielādēt nopirkto(s) failu(s):';
$_['text_new_comment'] = 'Komentāri pie Jūsu pasūtījuma:';
$_['text_new_footer'] = 'Lūdzu, atbildiet uz šo e-pasta ziņojumu, ja jums ir kādi jautājumi.';
$_['text_new_powered'] = 'Izstrādāts - "INDEEDD"';
$_['text_update_subject'] = '%s - Pasūtījuma izmaiņas %s';
$_['text_update_order'] = 'Pasūtījums Nr.:';
$_['text_update_date_added'] = 'Pasūtījuma datums:';
$_['text_update_order_status'] = 'Jūsu pasūtījums ir atjaunināts ar sekojošu stāvokli:';
$_['text_update_comment'] = 'Komentāri pie Jūsu pasūtījuma:';
$_['text_update_link'] = 'Savu pasūtījumu varat apskatīt šeit:';
$_['text_update_footer'] = 'Lūdzu, atbildiet uz šo e-pasta ziņojumu, ja Jums ir kādi jautājumi.';*/
?>