<?php
// Mail
$_['text_subject']      = '%s - Pasūtījuma precizējums  %s';
$_['text_order']        = 'Pasūtījuma numurs:';
$_['text_date_added']   = 'Pasūtījuma datums:';
$_['text_order_status'] = 'Jūsu pasūtījumam ir nomainīt statuss uz:';
$_['text_comment']      = 'Komentāri par jūsu pasūtījumu:';
$_['text_invoice']      = 'Lai apskatītu veikto pasūtījumu, nospiediet uz zemāk esošās hipersaites:';
$_['text_footer']       = 'Lūdzu atbildiet uz šo e-pasta vēstuli gadījumā, ja Jums ir radušies kādi jautājumi.';


?>