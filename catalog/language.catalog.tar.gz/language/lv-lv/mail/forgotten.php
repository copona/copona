<?php
// Text
$_['text_subject']  = '%s - Jaunā parole';
$_['text_greeting'] = 'Tika pieprasīta jaunā parole no portāla %s.';
$_['text_password'] = 'Jūsu jaunā parole ir:';
?>