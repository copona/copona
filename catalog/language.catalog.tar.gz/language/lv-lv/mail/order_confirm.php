<?php
// Text
$_['text_subject']          = '%s - Pasūtījums %s';
$_['text_greeting']         = 'Pateicamies par izrādīto interesi par %s produktiem. Jūsu pasūtījums tika saņemts un tiks nosūtīts tiklīdz būs saņemts maksājums';
$_['text_received']         = 'Jums ir jauns pasūtījums.';
$_['text_order_detail']     = 'Pasūtījuma detaļas';
$_['text_order_id']         = 'Pasūtījuma Nr:';
$_['text_date_added']       = 'Datums:';
$_['text_order_status']     = 'Statuss:';
$_['text_invoice']          = 'Lai aplūkotu pasūtījumu, klikšķiniet uz zemāk norādīto hipersaiti:';
$_['text_shipping_method']  = 'Piegādes veids:';
$_['text_payment_method']   = 'Maksāšanas veids:';
$_['text_shipping_address'] = 'Piegādes adrese';
$_['text_payment_address']  = 'Maksātāja adrese';
$_['text_email']  			= 'e-pasts:';
$_['text_telephone']  		= 'Tālruņa numurs:';
$_['text_ip']  				= 'IP adrese:';
$_['text_product']          = 'Produkti:';
$_['text_total']            = 'Kopā:';
$_['text_download']         = 'Tiklīdz maksājums tiks saņemts jūs varēsiet lejupielādēt produktus spiežot uz zemāk norādīto hipersaiti:';
$_['text_comment']          = 'Pasūtījumam pievienotie komentāri:';
$_['text_footer']           = 'Jautājumu gadījumā rakstīt uz šo e-pasta adresi.';
$_['text_powered_by']       = 'powered by';

// Column
$_['column_product']        = 'Produkts';
$_['column_model']          = 'Modelis';
$_['column_quantity']       = 'Daudzums';
$_['column_price']          = 'Cena';
$_['column_total']          = 'Kopā';	
?>