<?php
// Mail
$_['text_subject']    = '%s - Jauna parole';
$_['text_greeting']   = 'Jaunā parole tika pieprasīta no %s.';
$_['text_password']   = 'Jūsu jaunā parole ir:';
?>