<?php
$_['heading_title'] = 'Maksātāja adrese';
$_['text_basket'] = 'Iepirkumu grozs';
$_['text_shipping'] = 'Piegāde';
$_['text_payment'] = 'Apmaksa';
$_['text_address'] = 'Addrese';
$_['text_new_address'] = 'Jauna adrese';
$_['text_entries'] = 'Adrešu grāmatas ieraksti';
$_['entry_firstname'] = 'Vārds:';
$_['entry_lastname'] = 'Uzvārds:';
$_['entry_company'] = 'Uzņēmums:';
$_['entry_address_1'] = 'Addrese 1:';
$_['entry_address_2'] = 'Addrese 2:';
$_['entry_postcode'] = 'Pasta indekss:';
$_['entry_city'] = 'Pilsēta:';
$_['entry_zone'] = 'Rajons:';
$_['entry_country'] = 'Valsts:';
$_['entry_telephone'] = 'Telefona numurs:';
$_['entry_fax'] = 'Fakss:';
$_['error_firstname'] = 'Norādiet savu vārdu!';
$_['error_lastname'] = 'Norādiet savu uzvārdu!';
$_['error_address_1'] = 'Norādiet pilnu piegādes adresi!';
$_['error_city'] = 'Pilsētas nosaukumam ir jābūt garākam par 3, un īsākam par 32 zīmēm!';
$_['error_postcode'] = 'Pasta indeksam jābūt garākam par 2 un īsākam par 10 zīmēm!';
$_['error_country'] = 'Lūdzu, atzīmējiet valsti!';
$_['error_zone'] = 'Lūdzu, atzīmējiet rajonu!';
?>