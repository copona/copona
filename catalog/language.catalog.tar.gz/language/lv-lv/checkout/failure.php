<?php
$_['heading_title'] = 'Pasūtījums neizdevās';
$_['text_basket'] = 'Iepirkumu grozs';
$_['text_shipping'] = 'Piegāde';
$_['text_payment'] = 'Apmaksa';
$_['text_failure'] = 'Nesekmīgs';
$_['text_message'] = '<p>Radās kļūda veicot jūsu pasūtījuma reģistrēšanu!</p><p>Ja probēma atkārtojas, jūdzu izvēlaties citu maksāšanas metodi vai sazinaties ar veikala īpašnieku <a href="%s">spiežot šeit</a>.';
$_['text_checkout'] = 'PASŪTĪT';
?>