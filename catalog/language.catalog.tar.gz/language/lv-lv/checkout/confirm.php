<?php
// Heading 
$_['heading_title']                  = 'Pasūtījuma apstiprināšana';

// Text 
$_['text_basket']                    = 'Iepirkumu grozs';
$_['text_shipping']                  = 'Piegāde';
$_['text_payment']                   = 'Apmaksa';
$_['text_guest_step_1']              = 'Pasūtījums bez reģistrēšanās - 1. Solis';
$_['text_guest_step_2']              = 'Pasūtījums bez reģistrēšanās - 2. Solis';
$_['text_confirm']                   = 'Apstiprināt';
$_['text_shipping_address']          = 'Piegādes adrese';
$_['text_shipping_method']           = 'Piegādes veids';
$_['text_payment_address']           = 'Maksātāja adrese'; 
$_['text_payment_method']            = 'Apmaksas veids';
$_['text_change']                    = 'Mainīt';
$_['text_comment']                   = 'Jūsu komentāri';
$_['text_discount']                  = 'Atlaides kupons';
$_['text_coupon']                    = 'Ievadiet jūsu kupona kodu un nospiediet pogu "Pielietot". Atlaide nekavējoties tiks pielietota jūsu pasūtījumam.';
$_['text_success']                   = 'Jūsu norādīta kupona atlaide tika veiksmīgi pielietota';

// Entry
$_['entry_coupon']          = 'Kupons:';

// Columns
$_['column_product']                 = 'Produkts';
$_['column_model']                   = 'Modelis';
$_['column_quantity']                = 'Daudzums';
$_['column_price']                   = 'Cena';
$_['column_total']                   = 'Kopā';	

// Error
$_['error_coupon']    = 'Kļūda: Kupons ir vai nu nederīgs, ar iztecējušu lietošanas termiņu, vai sasniedzis tā pielietošanas limitu!';

?>
