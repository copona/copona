<?php
// Heading 
$_['heading_title']         = 'Pasūtījums bez reģistrēšanās - 2. solis';
 
// Text
$_['text_cart']             = 'Iepirkumu grozs';
$_['text_guest_step_1']     = 'Pasūtījums bez reģistrēšanās - 1. solis';
$_['text_guest_step_2']     = 'Pasūtījums bez reģistrēšanās - 2. solis';
$_['text_shipping_method']  = 'Piegādes veids';
$_['text_shipping_methods'] = 'Lūdzu norādīt sev vēlamo piegādes veidu šim pasūtījumam.';
$_['text_payment_method']   = 'Maksājuma veids';
$_['text_payment_methods']  = 'Lūdzu norādīt sev vēlamo apmaksas veidu šim pasūtījumam.';
$_['text_comments']         = 'Pievienot komentāru par veikto pasūtījumu';
$_['text_agree']            = 'Esmu izlasījis un piekrītu <a class="thickbox" href="index.php?route=information/information/loadInfo&checkout=1" alt="%s"><b>%s</b></a>';
$_['text_coupon']           = 'Ievadiet jūsu kupona kodu un nospiediet pogu "Pielietot". Atlaide nekavējoties tiks pievienota jūsu pasūtījumam.';
$_['text_success']          = 'Jūsu norādīta kupona atlaide tika veiksmīgi pielietota';

// Entry
$_['entry_shipping']        = 'Piegādes veids:';
$_['entry_payment']         = 'Apmaksas veids:';
$_['entry_coupon']          = 'Kupons:';

// Error
$_['error_shipping']        = 'Kļūda: Jānorāda piegādes veids!';
$_['error_no_shipping']     = 'Kļūda: Piegādes opcijas nav pieejamas. Lūdzuam <a href="index.php?route=information/contact">sazināties ar mums</a> lai iegūtu vairāk informācijas!';
$_['error_payment']         = 'Kļūda: Jānorāda maksāšanas veids!';
$_['error_agree']           = 'Kļūda: Jums jāpiekrīt %s!';
$_['error_coupon']          = 'Kļūda: Kupons ir vai nu nederīgs, ar iztecējušu lietošanas termiņu, vai sasniedzis tā pielietošanas limitu!';
?>