<?php
$_['error_stock'] = 'Izvēlētajā daudzumā, preces ar atzīmi ***  šobrīd nav pieejamas mūsu noliktavās!';
?>