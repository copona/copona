<?php
$_['heading_title'] = 'Pasūtījums bez reģistrēšanās';
$_['text_cart'] = 'Iepirkumu grozs';
$_['text_guest'] = 'Pasūtījums bez reģistrēšanās';
$_['text_your_details'] = 'Jūsu personīgā informācija';
$_['text_your_address'] = 'Jūsu adrese';
$_['text_shipping_method'] = 'Piegādes veids';
$_['text_shipping_methods'] = 'Lūdzu norādīt sev vēlamo piegādes veidu šim pasūtījumam.';
$_['text_payment_method'] = 'Maksājuma veids';
$_['text_payment_methods'] = 'Lūdzu norādīt sev vēlamo apmaksas veidu šim pasūtījumam.';
$_['text_comments'] = 'Pievienot komentāru par veikto pasūtījumu';
$_['text_agree'] = 'I have read and agree to the <a onclick="window.open(\'%s\');"><b>%s</b></a>';
$_['entry_firstname'] = 'Vārds:';
$_['entry_lastname'] = 'Uzvārds:';
$_['entry_email'] = 'E-pasts:';
$_['entry_telephone'] = 'Telefona numurs:';
$_['entry_fax'] = 'Fakss:';
$_['entry_company'] = 'Uzņēmums:';
$_['entry_address_1'] = 'Addrese 1:';
$_['entry_address_2'] = 'Addrese 2:';
$_['entry_postcode'] = 'Pasta indekss:';
$_['entry_city'] = 'Pilsēta:';
$_['entry_country'] = 'Valsts:';
$_['entry_zone'] = 'Rajons:';
$_['entry_shipping'] = 'Piegādes veids:';
$_['entry_payment'] = 'Apmaksas veids:';
$_['error_firstname'] = 'Norādiet savu vārdu!';
$_['error_lastname'] = 'Norādiet savu uzvārdu!';
$_['error_email'] = 'e-pasta adrese ievadīta kļūdaini!';
$_['error_telephone'] = 'Norādiet mob.tel. nr.!';
$_['error_address_1'] = 'Norādiet pilnu piegādes adresi!';
$_['error_city'] = 'Norādiet piegādes pilsētu!';
$_['error_country'] = 'Lūdzu, atzīmējiet valsti!';
$_['error_zone'] = 'Lūdzu, atzīmējiet rajonu!';
$_['error_shipping'] = 'Kļūda: Jānorāda piegādes veids!';
$_['error_payment'] = 'Kļūda: Jānorāda maksāšanas veids!';
$_['error_agree'] = 'Kļūda: Jums jāpiekrīt <a onclick="window.open(\'%s\');"><b>Interneta veikala %s lietošanas noteikumiem</b></a>!';

$_['error_address_2'] = 'Norādiet Juridisko adresi!';

$_['error_company_name'] = 'Norādiet uzņēmuma nosaukumu!';
$_['error_reg_num'] = 'Norādiet reģistrācijas numuru!';
$_['error_vat_num'] = 'Norādiet PVN numuru!';
$_['error_bank_name'] = 'Norādiet bankas nosaukumu!';
$_['error_bank_code'] = 'Norādiet bankas kodu!';
$_['error_bank_account'] = 'Norādiet kontu!';


?>