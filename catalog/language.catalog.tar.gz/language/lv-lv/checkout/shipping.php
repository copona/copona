<?php
// Heading
$_['heading_title']         = 'Informācija par piegādi';

// Text 
$_['text_basket']           = 'Iepirkumu grozs';
$_['text_shipping']         = 'Piegāde';
$_['text_shipping_to']      = 'Lūdzu norādīt adresi no adrešu gāmatas <br />uz kuru vēlaties lai mēs veicam piegādi.';
$_['text_shipping_address'] = 'Piegādes adrese';
$_['text_shipping_method']  = 'Piegādes veids';
$_['text_shipping_methods'] = 'Lūdzu norādiet vēlamo piegādes veidu šim pasūtījumam.';
$_['text_comments']         = 'Pievienot komentārus par jūsu pasūtījumu';

// Error
$_['error_shipping']        = 'Kļūda: Nepieciešams norādīt piegādes veidu!';
$_['error_no_shipping']     = 'Kļūda: Piegādes opcijas nav pieejamas. Lūdzuam <a href="index.php?route=information/contact">sazināties ar mums</a> lai iegūtu vairāk informācijas!';
?>