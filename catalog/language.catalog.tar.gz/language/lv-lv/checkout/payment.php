<?php
// Heading 
$_['heading_title']        = 'Informācija par apmaksu';

// Text
$_['text_basket']          = 'Iepirkumu grozs';
$_['text_shipping']        = 'Piegāde';
$_['text_payment']         = 'Apmaksa';
$_['text_payment_to']      = 'Lūdzu izvēlaties no adrešu grāmatas adresi uz kuru nosūtīt rēķinu.';
$_['text_payment_address'] = 'Maksājuma adrese';
$_['text_payment_method']  = 'Apmaksas veids';
$_['text_payment_methods'] = 'Lūdzu izvēlēties vēlamo maksāšanas veidu šim pasūtījumam.';
$_['text_comments']        = 'Pievienot komentārus par pasūtījumu';
$_['text_agree']           = 'Esmu izlasījis un piekrītu <a class="thickbox" href="index.php?route=information/information/loadInfo&checkout=1" alt="%s"><b>%s</b></a>';
$_['text_coupon']          = 'Ievadiet jūsu kupona kodu un nospiediet pogu "Pielietot". Atlaide nekavējoties tiks pievienota jūsu pasūtījumam.';
$_['text_success']         = 'Jūsu norādīta kupona atlaide tika veiksmīgi pielietota';

// Entry
$_['entry_coupon']       = 'Kupons:';


// Error
$_['error_payment']        = 'Kļūda: Nepieciešams norādīt maksāšanas veidu!';
$_['error_agree']          = 'Kļūda: Jums jāpiekrīt %s!';
$_['error_coupon']         = 'Kļūda: Kupons ir vai nu nederīgs, ar iztecējušu lietošanas termiņu, vai sasniedzis tā pielietošanas limitu!';
?>
