<?php
$_['heading_title'] = 'Jūsu pasūtījums noformēts!';
$_['text_customer'] = '<br>Jūsu pasūtījums ir veiksmīgi nodots apstrādei!<br>
Jūs varat apskatīt savu pasūtījumu vēsturi, ejot uz savu <a href="%s">Profilu</a> vai noklikšķinot uz tiešo vietni <a href="%s">Pasūtījumu vēsture</a>.<br>
Ja rodas kādi jautājumi saistība ar veikala lietošanas neskaidrībām, lūdzu, sazinieties ar veikala <a href="%s">administrāciju</a>.<br>
<br><b>Paldies par pirkumu, gaidīsim Jūs atkal!</b>';
$_['text_guest'] = '<br />Jūsu pasūtījums ir veiksmīgi nodots apstrādei!<br/>
Ja jums rodas kādi jautājumi, sazinieties ar <a href="%s">administrāciju</a>.<br/>
<br/><h3>Paldies par pirkumu, gaidīsim Jūs atkal!</h3><br />';
$_['text_basket'] = 'Iepirkumu grozs';
$_['text_checkout'] = 'Pasūtījuma apstrāde';
$_['text_success'] = 'Veiksmīgi';
$_['button_continue'] = 'Uz sākumu';
?>