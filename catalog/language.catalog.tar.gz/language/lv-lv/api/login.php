<?php
$_['error_login'] = 'Uzmanību: Lietotājs vai parole nav pareizi.';
?>