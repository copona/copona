<?php
$_['error_currency'] = 'Uzmanību: valūtas kods nav korekts!';
?>